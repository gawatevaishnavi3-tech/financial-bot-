import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { User, Income, Expense, Budget, SavingsGoal, FinancialReport, ChatMessage } from '../src/types';

interface DatabaseSchema {
  users: (User & { password_hash: string; salt: string })[];
  tokens: Record<string, string>; // token -> userId
  incomes: Income[];
  expenses: Expense[];
  budgets: Budget[];
  savingsGoals: SavingsGoal[];
  reports: FinancialReport[];
  chatHistory: Record<string, ChatMessage[]>; // userId -> messages
}

const DB_DIR = path.join(process.cwd(), 'data');
const DB_FILE = path.join(DB_DIR, 'finance_db.json');

// Helper to hash password
export function hashPassword(password: string, salt = crypto.randomBytes(16).toString('hex')): { hash: string; salt: string } {
  const hash = crypto.pbkdf2Sync(password, salt, 1000, 64, 'sha512').toString('hex');
  return { hash, salt };
}

export function verifyPassword(password: string, hash: string, salt: string): boolean {
  const check = crypto.pbkdf2Sync(password, salt, 1000, 64, 'sha512').toString('hex');
  return check === hash;
}

class Database {
  private data: DatabaseSchema;

  constructor() {
    this.data = this.load();
    if (this.data.users.length === 0) {
      this.seedInitialData();
    }
  }

  private load(): DatabaseSchema {
    try {
      if (!fs.existsSync(DB_DIR)) {
        fs.mkdirSync(DB_DIR, { recursive: true });
      }
      if (fs.existsSync(DB_FILE)) {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        return JSON.parse(raw);
      }
    } catch (e) {
      console.error('Error loading DB file, initializing empty schema:', e);
    }
    return {
      users: [],
      tokens: {},
      incomes: [],
      expenses: [],
      budgets: [],
      savingsGoals: [],
      reports: [],
      chatHistory: {},
    };
  }

  private save() {
    try {
      if (!fs.existsSync(DB_DIR)) {
        fs.mkdirSync(DB_DIR, { recursive: true });
      }
      const tmp = `${DB_FILE}.tmp`;
      fs.writeFileSync(tmp, JSON.stringify(this.data, null, 2), 'utf-8');
      fs.renameSync(tmp, DB_FILE);
    } catch (e) {
      console.error('Failed to save DB file:', e);
    }
  }

  public seedInitialData(targetUserId?: string) {
    const defaultUserId = targetUserId || 'usr_demo123';

    if (!targetUserId) {
      const { hash, salt } = hashPassword('demo123');
      const demoUser: User & { password_hash: string; salt: string } = {
        id: defaultUserId,
        username: 'Alex Sharma',
        email: 'alex@student.edu',
        currency: '₹',
        created_at: new Date(Date.now() - 60 * 24 * 3600 * 1000).toISOString(),
        password_hash: hash,
        salt: salt,
      };
      this.data.users.push(demoUser);
      this.data.tokens['demo_token_123'] = defaultUserId;
    }

    // Current date helpers
    const now = new Date();
    const currentYear = now.getFullYear();
    const currentMonth = now.getMonth() + 1;
    const pad = (n: number) => n.toString().padStart(2, '0');
    const yyyyMm = `${currentYear}-${pad(currentMonth)}`;

    // Incomes for current month & previous month
    const incomes: Income[] = [
      {
        id: 'inc_' + Math.random().toString(36).substring(2, 9),
        user_id: defaultUserId,
        amount: 35000,
        category: 'Salary',
        source: 'Tech Intern Monthly Stipend',
        date: `${yyyyMm}-01`,
        description: 'Monthly internship stipend credited',
        created_at: new Date().toISOString(),
      },
      {
        id: 'inc_' + Math.random().toString(36).substring(2, 9),
        user_id: defaultUserId,
        amount: 8500,
        category: 'Freelancing',
        source: 'Web Development Client',
        date: `${yyyyMm}-10`,
        description: 'Frontend landing page freelance project',
        created_at: new Date().toISOString(),
      },
      {
        id: 'inc_' + Math.random().toString(36).substring(2, 9),
        user_id: defaultUserId,
        amount: 3000,
        category: 'Allowance',
        source: 'Parents Support',
        date: `${yyyyMm}-05`,
        description: 'Monthly college book allowance',
        created_at: new Date().toISOString(),
      },
    ];

    // Expenses for current month
    const sampleExpenses: { category: string; amount: number; day: number; desc: string }[] = [
      { category: 'Rent', amount: 9500, day: 2, desc: 'Shared student apartment rent' },
      { category: 'Utilities', amount: 1400, day: 3, desc: 'Electricity & High-speed WiFi' },
      { category: 'Food', amount: 850, day: 4, desc: 'Weekly groceries at supermarket' },
      { category: 'Food', amount: 320, day: 6, desc: 'Campus cafeteria lunch & tea' },
      { category: 'Transport', amount: 1200, day: 7, desc: 'Monthly metro pass recharge' },
      { category: 'Education', amount: 1800, day: 9, desc: 'Cloud certification course fees' },
      { category: 'Food', amount: 950, day: 11, desc: 'Dinner with project team' },
      { category: 'Entertainment', amount: 1250, day: 13, desc: 'Weekend movie & snacks' },
      { category: 'Shopping', amount: 3400, day: 15, desc: 'Ergonomic study chair & accessories' },
      { category: 'Healthcare', amount: 650, day: 16, desc: 'Vitamins & prescription medicines' },
      { category: 'Food', amount: 750, day: 18, desc: 'Weekly grocery restock' },
      { category: 'Shopping', amount: 2100, day: 19, desc: 'New casual sneakers on discount' },
      { category: 'Transport', amount: 380, day: 20, desc: 'Late evening cab ride home' },
    ];

    const expenses: Expense[] = sampleExpenses.map((e, idx) => ({
      id: 'exp_' + idx + '_' + Math.random().toString(36).substring(2, 7),
      user_id: defaultUserId,
      amount: e.amount,
      category: e.category,
      date: `${yyyyMm}-${pad(Math.min(e.day, 28))}`,
      description: e.desc,
      created_at: new Date().toISOString(),
    }));

    // Budgets for current month
    const budgets: Budget[] = [
      { id: 'b_all_' + defaultUserId, user_id: defaultUserId, category: 'Overall', amount: 30000, month: currentMonth, year: currentYear, created_at: new Date().toISOString() },
      { id: 'b_1_' + defaultUserId, user_id: defaultUserId, category: 'Food', amount: 6000, month: currentMonth, year: currentYear, created_at: new Date().toISOString() },
      { id: 'b_2_' + defaultUserId, user_id: defaultUserId, category: 'Rent', amount: 9500, month: currentMonth, year: currentYear, created_at: new Date().toISOString() },
      { id: 'b_3_' + defaultUserId, user_id: defaultUserId, category: 'Shopping', amount: 4000, month: currentMonth, year: currentYear, created_at: new Date().toISOString() },
      { id: 'b_4_' + defaultUserId, user_id: defaultUserId, category: 'Entertainment', amount: 2000, month: currentMonth, year: currentYear, created_at: new Date().toISOString() },
      { id: 'b_5_' + defaultUserId, user_id: defaultUserId, category: 'Transport', amount: 2500, month: currentMonth, year: currentYear, created_at: new Date().toISOString() },
      { id: 'b_6_' + defaultUserId, user_id: defaultUserId, category: 'Education', amount: 3000, month: currentMonth, year: currentYear, created_at: new Date().toISOString() },
    ];

    // Savings goals
    const savingsGoals: SavingsGoal[] = [
      {
        id: 'sg_1_' + defaultUserId,
        user_id: defaultUserId,
        goal_name: 'Emergency Fund (3 Months)',
        target_amount: 50000,
        current_amount: 32000,
        deadline: `${currentYear}-12-31`,
        category: 'Safety Net',
        created_at: new Date().toISOString(),
      },
      {
        id: 'sg_2_' + defaultUserId,
        user_id: defaultUserId,
        goal_name: 'New Laptop for Final Year Project',
        target_amount: 75000,
        current_amount: 45000,
        deadline: `${currentYear}-11-15`,
        category: 'Gadgets',
        created_at: new Date().toISOString(),
      },
      {
        id: 'sg_3_' + defaultUserId,
        user_id: defaultUserId,
        goal_name: 'Post-Graduation Certification Exam',
        target_amount: 15000,
        current_amount: 11000,
        deadline: `${currentYear + 1}-03-31`,
        category: 'Education',
        created_at: new Date().toISOString(),
      },
    ];

    // Seed into data
    this.data.incomes.push(...incomes);
    this.data.expenses.push(...expenses);
    this.data.budgets.push(...budgets);
    this.data.savingsGoals.push(...savingsGoals);
    this.save();
  }

  // User methods
  public findUserByEmail(email: string) {
    const normalized = email.trim().toLowerCase();
    return this.data.users.find((u) => {
      const uEmail = u.email.toLowerCase();
      if (uEmail === normalized) return true;
      if (
        (normalized === 'alex@example.com' || normalized === 'alex@student.edu') &&
        (uEmail === 'alex@example.com' || uEmail === 'alex@student.edu')
      ) {
        return true;
      }
      return false;
    });
  }

  public findUserById(id: string): User | undefined {
    const user = this.data.users.find((u) => u.id === id);
    if (!user) return undefined;
    const { password_hash, salt, ...safeUser } = user;
    return safeUser;
  }

  public createUser(username: string, email: string, password: string, currency = '₹'): User {
    const { hash, salt } = hashPassword(password);
    const newUser = {
      id: 'usr_' + Date.now().toString(36) + Math.random().toString(36).substring(2, 6),
      username,
      email,
      currency,
      created_at: new Date().toISOString(),
      password_hash: hash,
      salt: salt,
    };
    this.data.users.push(newUser);
    this.seedInitialData(newUser.id);
    this.save();
    const { password_hash: _h, salt: _s, ...safeUser } = newUser;
    return safeUser;
  }

  public updateUserProfile(userId: string, updates: { username?: string; currency?: string }) {
    const user = this.data.users.find((u) => u.id === userId);
    if (!user) return null;
    if (updates.username) user.username = updates.username;
    if (updates.currency) user.currency = updates.currency;
    this.save();
    const { password_hash, salt, ...safeUser } = user;
    return safeUser;
  }

  // Token management
  public createToken(userId: string): string {
    const token = 'tok_' + crypto.randomBytes(24).toString('hex');
    this.data.tokens[token] = userId;
    this.save();
    return token;
  }

  public getUserIdByToken(token: string): string | null {
    return this.data.tokens[token] || null;
  }

  public deleteToken(token: string) {
    delete this.data.tokens[token];
    this.save();
  }

  // Income methods
  public getIncomes(userId: string): Income[] {
    return this.data.incomes.filter((i) => i.user_id === userId).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }

  public addIncome(userId: string, data: Omit<Income, 'id' | 'user_id' | 'created_at'>): Income {
    const item: Income = {
      id: 'inc_' + Date.now().toString(36) + Math.random().toString(36).substring(2, 6),
      user_id: userId,
      ...data,
      created_at: new Date().toISOString(),
    };
    this.data.incomes.push(item);
    this.save();
    return item;
  }

  public updateIncome(userId: string, id: string, data: Partial<Omit<Income, 'id' | 'user_id' | 'created_at'>>): Income | null {
    const idx = this.data.incomes.findIndex((i) => i.id === id && i.user_id === userId);
    if (idx === -1) return null;
    this.data.incomes[idx] = { ...this.data.incomes[idx], ...data };
    this.save();
    return this.data.incomes[idx];
  }

  public deleteIncome(userId: string, id: string): boolean {
    const initialLen = this.data.incomes.length;
    this.data.incomes = this.data.incomes.filter((i) => !(i.id === id && i.user_id === userId));
    const changed = this.data.incomes.length !== initialLen;
    if (changed) this.save();
    return changed;
  }

  // Expense methods
  public getExpenses(userId: string): Expense[] {
    return this.data.expenses.filter((e) => e.user_id === userId).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }

  public addExpense(userId: string, data: Omit<Expense, 'id' | 'user_id' | 'created_at'>): Expense {
    const item: Expense = {
      id: 'exp_' + Date.now().toString(36) + Math.random().toString(36).substring(2, 6),
      user_id: userId,
      ...data,
      created_at: new Date().toISOString(),
    };
    this.data.expenses.push(item);
    this.save();
    return item;
  }

  public updateExpense(userId: string, id: string, data: Partial<Omit<Expense, 'id' | 'user_id' | 'created_at'>>): Expense | null {
    const idx = this.data.expenses.findIndex((e) => e.id === id && e.user_id === userId);
    if (idx === -1) return null;
    this.data.expenses[idx] = { ...this.data.expenses[idx], ...data };
    this.save();
    return this.data.expenses[idx];
  }

  public deleteExpense(userId: string, id: string): boolean {
    const initialLen = this.data.expenses.length;
    this.data.expenses = this.data.expenses.filter((e) => !(e.id === id && e.user_id === userId));
    const changed = this.data.expenses.length !== initialLen;
    if (changed) this.save();
    return changed;
  }

  // Budget methods
  public getBudgets(userId: string, month?: number, year?: number): Budget[] {
    return this.data.budgets.filter((b) => {
      if (b.user_id !== userId) return false;
      if (month !== undefined && b.month !== month) return false;
      if (year !== undefined && b.year !== year) return false;
      return true;
    });
  }

  public setBudget(userId: string, category: string, amount: number, month: number, year: number): Budget {
    const existingIdx = this.data.budgets.findIndex(
      (b) => b.user_id === userId && b.category.toLowerCase() === category.toLowerCase() && b.month === month && b.year === year
    );
    if (existingIdx !== -1) {
      this.data.budgets[existingIdx].amount = amount;
      this.save();
      return this.data.budgets[existingIdx];
    }
    const newBudget: Budget = {
      id: 'bgt_' + Date.now().toString(36) + Math.random().toString(36).substring(2, 6),
      user_id: userId,
      category,
      amount,
      month,
      year,
      created_at: new Date().toISOString(),
    };
    this.data.budgets.push(newBudget);
    this.save();
    return newBudget;
  }

  public deleteBudget(userId: string, id: string): boolean {
    const initialLen = this.data.budgets.length;
    this.data.budgets = this.data.budgets.filter((b) => !(b.id === id && b.user_id === userId));
    const changed = this.data.budgets.length !== initialLen;
    if (changed) this.save();
    return changed;
  }

  // Savings Goals methods
  public getSavingsGoals(userId: string): SavingsGoal[] {
    return this.data.savingsGoals.filter((g) => g.user_id === userId).sort((a, b) => new Date(a.deadline).getTime() - new Date(b.deadline).getTime());
  }

  public addSavingsGoal(userId: string, data: Omit<SavingsGoal, 'id' | 'user_id' | 'created_at'>): SavingsGoal {
    const item: SavingsGoal = {
      id: 'sg_' + Date.now().toString(36) + Math.random().toString(36).substring(2, 6),
      user_id: userId,
      ...data,
      created_at: new Date().toISOString(),
    };
    this.data.savingsGoals.push(item);
    this.save();
    return item;
  }

  public updateSavingsGoal(userId: string, id: string, data: Partial<Omit<SavingsGoal, 'id' | 'user_id' | 'created_at'>>): SavingsGoal | null {
    const idx = this.data.savingsGoals.findIndex((g) => g.id === id && g.user_id === userId);
    if (idx === -1) return null;
    this.data.savingsGoals[idx] = { ...this.data.savingsGoals[idx], ...data };
    this.save();
    return this.data.savingsGoals[idx];
  }

  public deleteSavingsGoal(userId: string, id: string): boolean {
    const initialLen = this.data.savingsGoals.length;
    this.data.savingsGoals = this.data.savingsGoals.filter((g) => !(g.id === id && g.user_id === userId));
    const changed = this.data.savingsGoals.length !== initialLen;
    if (changed) this.save();
    return changed;
  }

  // Reports
  public getReports(userId: string): FinancialReport[] {
    return this.data.reports.filter((r) => r.user_id === userId).sort((a, b) => b.year - a.year || b.month - a.month);
  }

  public saveReport(userId: string, report: Omit<FinancialReport, 'id' | 'user_id' | 'created_at'>): FinancialReport {
    const existingIdx = this.data.reports.findIndex((r) => r.user_id === userId && r.month === report.month && r.year === report.year);
    if (existingIdx !== -1) {
      this.data.reports[existingIdx] = {
        ...this.data.reports[existingIdx],
        ...report,
      };
      this.save();
      return this.data.reports[existingIdx];
    }
    const item: FinancialReport = {
      id: 'rep_' + Date.now().toString(36) + Math.random().toString(36).substring(2, 6),
      user_id: userId,
      ...report,
      created_at: new Date().toISOString(),
    };
    this.data.reports.push(item);
    this.save();
    return item;
  }

  // Chat History
  public getChatHistory(userId: string): ChatMessage[] {
    return this.data.chatHistory[userId] || [];
  }

  public addChatMessage(userId: string, role: 'user' | 'assistant', content: string): ChatMessage {
    if (!this.data.chatHistory[userId]) {
      this.data.chatHistory[userId] = [];
    }
    const msg: ChatMessage = {
      id: 'msg_' + Date.now() + Math.random().toString(36).substring(2, 5),
      role,
      content,
      timestamp: new Date().toISOString(),
    };
    this.data.chatHistory[userId].push(msg);
    // Keep last 30 messages
    if (this.data.chatHistory[userId].length > 30) {
      this.data.chatHistory[userId] = this.data.chatHistory[userId].slice(-30);
    }
    this.save();
    return msg;
  }

  public clearChatHistory(userId: string) {
    this.data.chatHistory[userId] = [];
    this.save();
  }

  // Reset user data to initial demo state
  public resetUserData(userId: string) {
    this.data.incomes = this.data.incomes.filter((i) => i.user_id !== userId);
    this.data.expenses = this.data.expenses.filter((e) => e.user_id !== userId);
    this.data.budgets = this.data.budgets.filter((b) => b.user_id !== userId);
    this.data.savingsGoals = this.data.savingsGoals.filter((g) => g.user_id !== userId);
    this.data.reports = this.data.reports.filter((r) => r.user_id !== userId);
    this.data.chatHistory[userId] = [];
    this.seedInitialData(userId);
  }
}

export const db = new Database();
