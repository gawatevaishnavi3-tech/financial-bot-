export interface ProjectFile {
  filename: string;
  path: string;
  category: 'config' | 'model' | 'route' | 'service' | 'template' | 'docs';
  description: string;
  content: string;
}

export const PYTHON_PROJECT_FILES: ProjectFile[] = [
  {
    filename: 'requirements.txt',
    path: 'requirements.txt',
    category: 'config',
    description: 'Python package dependencies for the Flask application',
    content: `Flask==3.0.3
Flask-SQLAlchemy==3.1.1
Flask-Login==0.6.3
python-dotenv==1.0.1
google-genai==0.1.1
werkzeug==3.0.3
email-validator==2.1.1
gunicorn==22.0.0
pytest==8.2.0
pyngrok==7.1.6
`,
  },
  {
    filename: '.env.example',
    path: '.env.example',
    category: 'config',
    description: 'Sample environment variables configuration',
    content: `# Flask Secret Key for session encryption
SECRET_KEY=generate_a_secure_random_key_here

# Database Configuration (SQLite by default, compatible with PostgreSQL)
DATABASE_URL=sqlite:///instance/finance.db
# For PostgreSQL in production:
# DATABASE_URL=postgresql://username:password@localhost:5432/finance_db

# Google Gemini API Key for Financial Advisor
GEMINI_API_KEY=your_gemini_api_key_here

# Flask Environment
FLASK_ENV=development
FLASK_DEBUG=1
PORT=5000
`,
  },
  {
    filename: 'app.py',
    path: 'app.py',
    category: 'config',
    description: 'Main Flask application factory and entry point',
    content: `"""
Personal Finance Advisor Bot
Main Application Entry Point & Factory
"""
import os
from flask import Flask, render_template, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, current_user
from dotenv import load_dotenv

load_dotenv()

db = SQLAlchemy()
login_manager = LoginManager()

def create_app(test_config=None):
    app = Flask(__name__, instance_relative_config=True)
    
    app.config.from_mapping(
        SECRET_KEY=os.environ.get('SECRET_KEY', 'dev_default_secret_key_change_in_prod'),
        SQLALCHEMY_DATABASE_URI=os.environ.get('DATABASE_URL', 'sqlite:///finance.db'),
        SQLALCHEMY_TRACK_MODIFICATIONS=False,
    )
    
    os.makedirs(app.instance_path, exist_ok=True)
    
    db.init_app(app)
    login_manager.init_app(app)
    login_manager.login_view = 'auth.login'
    login_manager.login_message_category = 'info'
    
    from models.user import User
    
    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))
    
    # Register Blueprints
    from routes.auth import auth_bp
    from routes.dashboard import dashboard_bp
    from routes.income import income_bp
    from routes.expenses import expense_bp
    from routes.budget import budget_bp
    from routes.savings import savings_bp
    from routes.advisor import advisor_bp
    from routes.reports import report_bp
    
    app.register_blueprint(auth_bp)
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(income_bp, url_prefix='/income')
    app.register_blueprint(expense_bp, url_prefix='/expenses')
    app.register_blueprint(budget_bp, url_prefix='/budget')
    app.register_blueprint(savings_bp, url_prefix='/savings')
    app.register_blueprint(advisor_bp, url_prefix='/advisor')
    app.register_blueprint(report_bp, url_prefix='/reports')
    
    @app.route('/')
    def index():
        if current_user.is_authenticated:
            return redirect(url_for('dashboard.index'))
        return render_template('index.html')

    with app.app_context():
        db.create_all()
        
    return app

if __name__ == '__main__':
    app = create_app()
    app.run(host='0.0.0.0', port=int(os.environ.get('PORT', 5000)), debug=True)
`,
  },
  {
    filename: 'models.py',
    path: 'models/__init__.py',
    category: 'model',
    description: 'SQLAlchemy Database Models for User, Income, Expense, Budget, SavingsGoal, FinancialReport',
    content: `"""
SQLAlchemy Models for Personal Finance Advisor Bot
"""
from datetime import datetime
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from app import db

class User(UserMixin, db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    currency = db.Column(db.String(10), default='₹')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # Relationships
    incomes = db.relationship('Income', backref='user', lazy=True, cascade='all, delete-orphan')
    expenses = db.relationship('Expense', backref='user', lazy=True, cascade='all, delete-orphan')
    budgets = db.relationship('Budget', backref='user', lazy=True, cascade='all, delete-orphan')
    savings_goals = db.relationship('SavingsGoal', backref='user', lazy=True, cascade='all, delete-orphan')
    reports = db.relationship('FinancialReport', backref='user', lazy=True, cascade='all, delete-orphan')

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class Income(db.Model):
    __tablename__ = 'incomes'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    category = db.Column(db.String(50), nullable=False) # Salary, Freelancing, Business, etc.
    source = db.Column(db.String(100), nullable=False)
    date = db.Column(db.Date, nullable=False, default=datetime.utcnow)
    description = db.Column(db.String(255), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Expense(db.Model):
    __tablename__ = 'expenses'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    category = db.Column(db.String(50), nullable=False) # Food, Rent, Transport, etc.
    date = db.Column(db.Date, nullable=False, default=datetime.utcnow)
    description = db.Column(db.String(255), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Budget(db.Model):
    __tablename__ = 'budgets'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False)
    category = db.Column(db.String(50), nullable=False) # 'Overall' or specific category
    amount = db.Column(db.Float, nullable=False)
    month = db.Column(db.Integer, nullable=False) # 1-12
    year = db.Column(db.Integer, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class SavingsGoal(db.Model):
    __tablename__ = 'savings_goals'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False)
    goal_name = db.Column(db.String(100), nullable=False)
    target_amount = db.Column(db.Float, nullable=False)
    current_amount = db.Column(db.Float, default=0.0)
    deadline = db.Column(db.Date, nullable=False)
    category = db.Column(db.String(50), default='General')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    @property
    def progress_percentage(self):
        if self.target_amount <= 0:
            return 0
        return min(100, round((self.current_amount / self.target_amount) * 100, 1))

class FinancialReport(db.Model):
    __tablename__ = 'financial_reports'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False)
    month = db.Column(db.Integer, nullable=False)
    year = db.Column(db.Integer, nullable=False)
    income = db.Column(db.Float, nullable=False)
    expenses = db.Column(db.Float, nullable=False)
    savings = db.Column(db.Float, nullable=False)
    highest_category = db.Column(db.String(50), nullable=True)
    ai_recommendations = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
`,
  },
  {
    filename: 'ai_service.py',
    path: 'services/ai_service.py',
    category: 'service',
    description: 'AI Prompt Engineering & Gemini API Client Service',
    content: `"""
AI Service for Personal Finance Advisor Bot
Handles structured prompt engineering and API calls using Google Gemini
"""
import os
import json
from google import genai
from google.genai import types

def get_gemini_client():
    api_key = os.environ.get('GEMINI_API_KEY')
    if not api_key:
        return None
    return genai.Client(api_key=api_key)

def generate_financial_advice(financial_data):
    """
    financial_data dictionary contains:
    - monthly_income
    - monthly_expenses
    - monthly_savings
    - budget
    - category_expenses (dict)
    - category_budgets (dict)
    - savings_goals (list)
    - currency
    """
    client = get_gemini_client()
    currency = financial_data.get('currency', '₹')
    
    # Prompt Engineering Structure (Module 9)
    prompt = f"""
    You are an expert AI Personal Finance Advisor Bot.
    Analyze the following user financial profile:

    Monthly Income: {currency}{financial_data['monthly_income']:,.2f}
    Monthly Expenses: {currency}{financial_data['monthly_expenses']:,.2f}
    Monthly Savings: {currency}{financial_data['monthly_savings']:,.2f}
    Configured Budget: {currency}{financial_data['budget']:,.2f}

    Category-wise Expenses:
    {json.dumps(financial_data['category_expenses'], indent=2)}

    Category-wise Budgets:
    {json.dumps(financial_data['category_budgets'], indent=2)}

    Active Savings Goals:
    {json.dumps(financial_data['savings_goals'], indent=2)}

    Please return a valid JSON object with the following structured keys:
    1. spending_summary: (string) Overall spending behavior analysis.
    2. overspending_categories: (list of dicts with category, spent, budget, excess, severity)
    3. recommended_budget: (list of dicts with category, suggested_limit, rationale)
    4. savings_suggestions: (list of actionable tips)
    5. cost_cutting_suggestions: (list of practical reduction areas)
    6. emergency_fund_suggestion: (dict with target_months, recommended_target, steps_to_reach)
    7. next_month_action_plan: (list of 4 sequential steps)
    8. financial_health_score: (integer 0-100)
    9. financial_health_grade: (string A, B, C, D, or F)
    """

    if not client:
        # Graceful rule-based fallback when offline or no API key
        return generate_rule_based_fallback(financial_data)

    try:
        response = client.models.generate_content(
            model='gemini-2.5-flash',
            contents=prompt,
            config=types.GenerateContentConfig(
                response_mime_type='application/json'
            )
        )
        return json.loads(response.text)
    except Exception as e:
        print(f"Gemini API error: {e}")
        return generate_rule_based_fallback(financial_data)

def generate_rule_based_fallback(data):
    currency = data.get('currency', '₹')
    income = data['monthly_income']
    expenses = data['monthly_expenses']
    savings = data['monthly_savings']
    cat_exp = data.get('category_expenses', {})
    cat_bud = data.get('category_budgets', {})

    overspending = []
    recommended = []
    for cat, spent in cat_exp.items():
        limit = cat_bud.get(cat, data['budget'] * 0.15 if data['budget'] else spent)
        if spent > limit and limit > 0:
            overspending.append({
                'category': cat,
                'spent': spent,
                'budget': limit,
                'excess': spent - limit,
                'severity': 'high' if (spent / limit) > 1.3 else 'moderate'
            })
        recommended.append({
            'category': cat,
            'suggested_limit': round(spent * 0.9, -1),
            'rationale': f'Calculated 10% reduction benchmark for {cat}'
        })

    savings_rate = (savings / income * 100) if income > 0 else 0
    score = min(100, max(20, int(50 + savings_rate)))
    grade = 'A' if score >= 85 else 'B' if score >= 70 else 'C' if score >= 55 else 'D'

    return {
        'spending_summary': f'Your monthly income is {currency}{income:,.2f} with total expenses of {currency}{expenses:,.2f}, yielding {currency}{savings:,.2f} net savings (Savings rate: {savings_rate:.1f}%).',
        'overspending_categories': overspending,
        'recommended_budget': recommended,
        'savings_suggestions': [
            'Direct at least 20% of monthly income into a dedicated savings reserve immediately upon receipt.',
            'Audit recurring subscriptions and cancel unused memberships.'
        ],
        'cost_cutting_suggestions': [
            'Plan weekly grocery lists to curb impulsive food takeaway purchases.',
            'Utilize student/commuter passes to minimize transit expenditures.'
        ],
        'emergency_fund_suggestion': {
            'target_months': 3,
            'recommended_target': expenses * 3,
            'steps_to_reach': f'Save {currency}{expenses * 0.5:,.2f} per month to complete an emergency fund in 6 months.'
        },
        'next_month_action_plan': [
            'Set strict spending caps on top categories before the first week begins.',
            'Log each expenditure on the day it occurs.',
            'Review budget utilization midway through the month.'
        ],
        'financial_health_score': score,
        'financial_health_grade': grade
    }
`,
  },
  {
    filename: 'viva_questions.md',
    path: 'docs/viva_questions_and_answers.md',
    category: 'docs',
    description: 'College Project Viva Questions, Answers & Architecture Guide',
    content: `# College Project Viva Examination Guide
## Personal Finance Advisor Bot (AI + Full-Stack FinTech)

### 1. What is the core problem solved by this project?
**Answer:** Many individuals, students, and young professionals struggle with financial discipline due to manual tracking friction and lack of personalized financial expertise. This project automates income/expense tracking, calculates real-time budget utilization, detects category overspending, monitors savings milestones, and leverages Generative AI (Google Gemini) to provide structured financial recommendations (such as 50/30/20 budget allocations and emergency fund targets).

---

### 2. Explain the system architecture and data isolation.
**Answer:** The system implements a three-tier architecture:
1. **Presentation Layer:** Responsive, accessible web interface with interactive visual charts (category donuts, monthly trend bars, progress meters).
2. **Application / Business Layer:** Flask REST API with role-isolated controllers, authentication services, and an AI prompt engineering pipeline.
3. **Persistence Layer:** Relational schema (SQLAlchemy) with foreign-key constraints linking User, Income, Expense, Budget, SavingsGoal, and FinancialReport.
- **Data Isolation:** All queries explicitly filter by \`current_user.id\` or authenticated token, ensuring zero cross-tenant data leakage.

---

### 3. How does the AI integration work?
**Answer:** The system does not send unformatted user chat to the model. Instead, it extracts verified database records (monthly income, total expenses, category-wise expenditure, current budget limits, and savings goals) and injects them into a structured prompt using prompt engineering principles. The model (Gemini 2.5/3.8 Flash) is configured to return strict JSON matching an exact schema (spending summary, overspending alerts, recommended category caps, cost-cutting tips, emergency fund milestones, and next-month action steps).

---

### 4. What is the difference between factual calculations and AI recommendations?
**Answer:** Factual calculations (e.g., \`Remaining Budget = Budget - Expenses\`, \`Savings Progress % = (Current / Target) * 100\`) are computed deterministically in the backend code and database queries. The AI is used purely for heuristic analysis, pattern detection, budgeting recommendations, and cost-cutting suggestions. This ensures mathematical accuracy without hallucination.

---

### 5. How do you deploy and demonstrate with Ngrok?
**Answer:**
1. Run \`python app.py\` (or start the web server on local port).
2. Run \`ngrok http 5000\` in terminal.
3. Ngrok creates a secure public HTTPS tunnel to the local server.
4. Open the generated HTTPS URL on any mobile device or external browser for remote evaluation.
`,
  },
];
