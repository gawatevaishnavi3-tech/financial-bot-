import { GoogleGenAI } from '@google/genai';
import { AIAnalysisResult } from '../src/types';

let aiClient: GoogleGenAI | null = null;

function getAI(): GoogleGenAI | null {
  if (!process.env.GEMINI_API_KEY) {
    return null;
  }
  if (!aiClient) {
    aiClient = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

export interface FinancialContextData {
  currency: string;
  monthlyIncome: number;
  monthlyExpenses: number;
  monthlySavings: number;
  budget: number;
  categories: Record<string, number>;
  categoryBudgets: Record<string, number>;
  savingsGoals: { name: string; target: number; current: number; deadline: string }[];
  recentTransactions: { type: 'income' | 'expense'; category: string; amount: number; description?: string; date: string }[];
}

// Fallback rule-based analysis if API key is not yet set or in case of network limits
function generateFallbackAnalysis(data: FinancialContextData): AIAnalysisResult {
  const currency = data.currency || '₹';
  const overspending: AIAnalysisResult['overspending_categories'] = [];
  const recommendedBudget: AIAnalysisResult['recommended_budget'] = [];

  for (const [cat, spent] of Object.entries(data.categories)) {
    const budgeted = data.categoryBudgets[cat] || (data.budget > 0 ? Math.round(data.budget * 0.15) : 0);
    if (budgeted > 0 && spent > budgeted) {
      const excess = spent - budgeted;
      const ratio = spent / budgeted;
      overspending.push({
        category: cat,
        spent,
        budget: budgeted,
        excess,
        severity: ratio > 1.5 ? 'critical' : ratio > 1.2 ? 'high' : 'moderate',
      });
    }

    // Recommended limit
    recommendedBudget.push({
      category: cat,
      suggested_limit: Math.round(Math.max(spent * 0.9, budgeted || spent * 0.8)),
      rationale: `Targeting 10% optimization based on ${cat} historical consumption.`,
    });
  }

  const savingsRate = data.monthlyIncome > 0 ? (data.monthlySavings / data.monthlyIncome) * 100 : 0;
  let score = 75;
  let grade: AIAnalysisResult['financial_health_grade'] = 'B';

  if (savingsRate >= 30 && overspending.length === 0) {
    score = 92;
    grade = 'A';
  } else if (savingsRate >= 20 && overspending.length <= 1) {
    score = 82;
    grade = 'B';
  } else if (savingsRate >= 10) {
    score = 68;
    grade = 'C';
  } else if (savingsRate > 0) {
    score = 54;
    grade = 'D';
  } else {
    score = 38;
    grade = 'F';
  }

  const emergencyMonths = 3;
  const avgMonthlyExpense = data.monthlyExpenses || 20000;
  const emergencyTarget = avgMonthlyExpense * emergencyMonths;

  return {
    spending_summary: `Your total monthly income is ${currency}${data.monthlyIncome.toLocaleString()}, against total expenses of ${currency}${data.monthlyExpenses.toLocaleString()}, generating net savings of ${currency}${data.monthlySavings.toLocaleString()} (Savings Rate: ${savingsRate.toFixed(1)}%). Your primary expense categories are ${Object.keys(data.categories).slice(0, 3).join(', ')}.`,
    overspending_categories: overspending,
    recommended_budget: recommendedBudget,
    savings_suggestions: [
      `Automate a recurring transfer of at least ${currency}${Math.round(data.monthlyIncome * 0.2).toLocaleString()} (20%) directly into your high-yield savings on salary day.`,
      `Review discretionary subscriptions and non-essential dining expenses to increase monthly savings buffer by 15%.`,
      `Utilize the 50/30/20 rule: 50% for Needs, 30% for Wants, and 20% dedicated strictly to debt repayment and savings goals.`,
    ],
    cost_cutting_suggestions: [
      `Meal-prep 3 days a week to lower food delivery & dining out costs by up to 25%.`,
      `Consolidate streaming services and mobile subscriptions to save recurring monthly overheads.`,
      `Compare utility tariffs and student transit passes for reduced transport fares.`,
    ],
    emergency_fund_suggestion: {
      current_estimate: Math.max(0, data.monthlySavings * 2),
      target_months: emergencyMonths,
      recommended_target: emergencyTarget,
      steps_to_reach: `Accumulate ${currency}${Math.round(emergencyTarget / 6).toLocaleString()}/month over the next 6 months to secure a resilient 3-month safety cushion.`,
    },
    next_month_action_plan: [
      `Lock in strict category budgets before the 1st of next month, especially for high-spend categories.`,
      `Track daily micro-expenses (snacks, coffee, cab rides) using the daily expense log.`,
      `Fund your active savings goals with at least 15% of your primary income source.`,
      `Review budget utilization weekly to prevent month-end overspending surprises.`,
    ],
    financial_health_score: score,
    financial_health_grade: grade,
    generated_at: new Date().toISOString(),
  };
}

export async function generateAIAnalysis(context: FinancialContextData): Promise<AIAnalysisResult> {
  const ai = getAI();
  if (!ai) {
    console.log('No GEMINI_API_KEY detected, using intelligent rule-based financial advisor');
    return generateFallbackAnalysis(context);
  }

  const prompt = `
You are an expert AI Personal Finance Advisor Bot and certified FinTech specialist analyzing a user's financial profile.

Financial Profile:
Currency: ${context.currency}
Monthly Income: ${context.currency}${context.monthlyIncome.toLocaleString()}
Monthly Expenses: ${context.currency}${context.monthlyExpenses.toLocaleString()}
Monthly Savings (Income - Expenses): ${context.currency}${context.monthlySavings.toLocaleString()}
Overall Set Budget: ${context.currency}${context.budget.toLocaleString()}

Category-wise Monthly Expenses:
${Object.entries(context.categories)
  .map(([cat, amt]) => `- ${cat}: ${context.currency}${amt.toLocaleString()} (Budgeted limit: ${context.currency}${(context.categoryBudgets[cat] || 0).toLocaleString()})`)
  .join('\n')}

Savings Goals:
${context.savingsGoals.map((g) => `- ${g.name}: Target ${context.currency}${g.target.toLocaleString()}, Current ${context.currency}${g.current.toLocaleString()}, Deadline: ${g.deadline}`).join('\n') || 'None recorded'}

Recent Transactions Sample:
${context.recentTransactions.slice(0, 8).map((t) => `* [${t.type.toUpperCase()}] ${t.date} | ${t.category}: ${context.currency}${t.amount} (${t.description || 'No notes'})`).join('\n') || 'None'}

TASK:
Provide a rigorous, empathetic, realistic, and highly actionable personal financial assessment.
Return a STRICT JSON object matching this schema:
{
  "spending_summary": "A 2-3 sentence overview of their spending behavior, cash flow, and savings rate.",
  "overspending_categories": [
    {
      "category": "string",
      "spent": number,
      "budget": number,
      "excess": number,
      "severity": "moderate" | "high" | "critical"
    }
  ],
  "recommended_budget": [
    {
      "category": "string",
      "suggested_limit": number,
      "rationale": "short explanation"
    }
  ],
  "savings_suggestions": ["string", "string", "string"],
  "cost_cutting_suggestions": ["string", "string", "string"],
  "emergency_fund_suggestion": {
    "current_estimate": number,
    "target_months": number,
    "recommended_target": number,
    "steps_to_reach": "string"
  },
  "next_month_action_plan": ["step 1", "step 2", "step 3", "step 4"],
  "financial_health_score": number (0-100),
  "financial_health_grade": "A" | "B" | "C" | "D" | "F"
}

Important:
- Return valid JSON only. Do not include markdown wrappers like \`\`\`json.
- Clearly ground calculations on the provided numbers.
- Differentiate informative guidance from professional advice.
`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const text = response.text || '';
    const cleaned = text.replace(/^```json\s*/i, '').replace(/```$/i, '').trim();
    const parsed: AIAnalysisResult = JSON.parse(cleaned);
    parsed.generated_at = new Date().toISOString();
    return parsed;
  } catch (err) {
    console.error('Gemini API call failed, falling back to rule-based analysis:', err);
    return generateFallbackAnalysis(context);
  }
}

export async function askFinancialAdvisorChat(
  context: FinancialContextData,
  conversationHistory: { role: 'user' | 'assistant'; content: string }[],
  userMessage: string
): Promise<string> {
  const ai = getAI();
  if (!ai) {
    // Intelligent contextual response
    return `As your Financial Advisor Bot, I see your current monthly income is ${context.currency}${context.monthlyIncome.toLocaleString()} and expenses are ${context.currency}${context.monthlyExpenses.toLocaleString()}, leaving ${context.currency}${context.monthlySavings.toLocaleString()} in net savings. To answer "${userMessage}": Focus on tracking high-frequency expenses in ${Object.keys(context.categories)[0] || 'daily necessities'}, maintain at least a 20% savings buffer, and consider allocating towards your active savings goals! (Note: Add GEMINI_API_KEY in Secrets for live AI conversational reasoning).`;
  }

  const systemInstruction = `
You are "Personal Finance Advisor Bot", a friendly, knowledgeable, and certified digital FinTech financial mentor.
You have real-time access to the user's isolated financial ledger:
- Currency: ${context.currency}
- Monthly Income: ${context.currency}${context.monthlyIncome.toLocaleString()}
- Monthly Expenses: ${context.currency}${context.monthlyExpenses.toLocaleString()}
- Net Monthly Savings: ${context.currency}${context.monthlySavings.toLocaleString()}
- Budget Limit: ${context.currency}${context.budget.toLocaleString()}
- Category Expenses: ${JSON.stringify(context.categories)}
- Category Budgets: ${JSON.stringify(context.categoryBudgets)}
- Savings Goals: ${JSON.stringify(context.savingsGoals)}

Guidelines:
- Give concise, practical, mathematically sound financial tips.
- When the user asks how to save money, cite their actual expense categories and numbers.
- Provide step-by-step actionable guidance.
- Keep tone professional, encouraging, and clear.
- Explicitly present advice as general educational guidance.
`;

  try {
    const contents = [
      ...conversationHistory.slice(-6).map((m) => ({
        role: m.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: m.content }],
      })),
      {
        role: 'user',
        parts: [{ text: userMessage }],
      },
    ];

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: contents as any,
      config: {
        systemInstruction,
      },
    });

    return response.text || 'I have analyzed your financial records. Please ensure your budget limits are aligned with your monthly income.';
  } catch (err) {
    console.error('Gemini chat error:', err);
    return `Based on your financials (${context.currency}${context.monthlySavings.toLocaleString()} current monthly savings): Focus on controlling your top spending category (${Object.keys(context.categories)[0] || 'discretionary purchases'}) and allocating funds systematically towards your goals.`;
  }
}
