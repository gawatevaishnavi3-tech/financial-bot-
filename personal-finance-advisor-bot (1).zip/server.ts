import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';
import { db, verifyPassword } from './server/db';
import { generateAIAnalysis, askFinancialAdvisorChat, FinancialContextData } from './server/gemini';
import { PYTHON_PROJECT_FILES } from './server/pythonProjectFiles';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Authentication Middleware
interface AuthenticatedRequest extends Request {
  userId?: string;
}

const authMiddleware = (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  const authHeader = req.headers.authorization;
  const token = authHeader && authHeader.startsWith('Bearer ') ? authHeader.substring(7) : (req.query.token as string);

  if (!token) {
    res.status(401).json({ error: 'Authentication required. Please log in.' });
    return;
  }

  const userId = db.getUserIdByToken(token);
  if (!userId) {
    res.status(401).json({ error: 'Session expired or invalid token. Please log in again.' });
    return;
  }

  req.userId = userId;
  next();
};

// Helper to gather financial context for a user
function buildUserFinancialContext(userId: string, month?: number, year?: number): FinancialContextData {
  const user = db.findUserById(userId);
  const currency = user?.currency || '₹';

  const now = new Date();
  const targetYear = year || now.getFullYear();
  const targetMonth = month || now.getMonth() + 1;
  const pad = (n: number) => n.toString().padStart(2, '0');
  const yyyyMm = `${targetYear}-${pad(targetMonth)}`;

  const allIncomes = db.getIncomes(userId);
  const allExpenses = db.getExpenses(userId);
  const budgets = db.getBudgets(userId, targetMonth, targetYear);
  const savingsGoals = db.getSavingsGoals(userId);

  // Filter current month
  const monthIncomes = allIncomes.filter((i) => i.date.startsWith(yyyyMm));
  const monthExpenses = allExpenses.filter((e) => e.date.startsWith(yyyyMm));

  const monthlyIncome = monthIncomes.reduce((sum, i) => sum + i.amount, 0);
  const monthlyExpenses = monthExpenses.reduce((sum, e) => sum + e.amount, 0);
  const monthlySavings = monthlyIncome - monthlyExpenses;

  // Budgets map
  const overallBudgetObj = budgets.find((b) => b.category.toLowerCase() === 'overall');
  const budget = overallBudgetObj ? overallBudgetObj.amount : 0;

  const categoryBudgets: Record<string, number> = {};
  budgets.forEach((b) => {
    if (b.category.toLowerCase() !== 'overall') {
      categoryBudgets[b.category] = b.amount;
    }
  });

  const categories: Record<string, number> = {};
  monthExpenses.forEach((e) => {
    categories[e.category] = (categories[e.category] || 0) + e.amount;
  });

  const recentTransactions = [
    ...monthIncomes.map((i) => ({ type: 'income' as const, category: i.category, amount: i.amount, description: i.source + (i.description ? ` - ${i.description}` : ''), date: i.date })),
    ...monthExpenses.map((e) => ({ type: 'expense' as const, category: e.category, amount: e.amount, description: e.description, date: e.date })),
  ].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  return {
    currency,
    monthlyIncome,
    monthlyExpenses,
    monthlySavings,
    budget,
    categories,
    categoryBudgets,
    savingsGoals: savingsGoals.map((g) => ({
      name: g.goal_name,
      target: g.target_amount,
      current: g.current_amount,
      deadline: g.deadline,
    })),
    recentTransactions,
  };
}

// ---------------- API ROUTES ----------------

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', service: 'Personal Finance Advisor Bot', timestamp: new Date().toISOString() });
});

// Auth Routes
app.post('/api/auth/register', (req, res) => {
  const { username, email, password, currency } = req.body;
  if (!username || !email || !password) {
    res.status(400).json({ error: 'Username, email, and password are required.' });
    return;
  }

  const existing = db.findUserByEmail(email);
  if (existing) {
    res.status(400).json({ error: 'An account with this email already exists. Please log in.' });
    return;
  }

  const user = db.createUser(username.trim(), email.trim(), password, currency || '₹');
  const token = db.createToken(user.id);
  res.status(201).json({ user, token });
});

app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    res.status(400).json({ error: 'Email and password are required.' });
    return;
  }

  const userWithSecrets = db.findUserByEmail(email);
  if (!userWithSecrets) {
    res.status(401).json({ error: 'Invalid email or password.' });
    return;
  }

  const isValid = verifyPassword(password, userWithSecrets.password_hash, userWithSecrets.salt);
  if (!isValid) {
    res.status(401).json({ error: 'Invalid email or password.' });
    return;
  }

  const token = db.createToken(userWithSecrets.id);
  const { password_hash, salt, ...safeUser } = userWithSecrets;
  res.json({ user: safeUser, token });
});

app.get('/api/auth/me', authMiddleware, (req: AuthenticatedRequest, res) => {
  const user = db.findUserById(req.userId!);
  if (!user) {
    res.status(404).json({ error: 'User not found.' });
    return;
  }
  res.json({ user });
});

app.post('/api/auth/logout', authMiddleware, (req: AuthenticatedRequest, res) => {
  const token = req.headers.authorization?.substring(7);
  if (token) db.deleteToken(token);
  res.json({ success: true, message: 'Logged out successfully.' });
});

app.put('/api/auth/profile', authMiddleware, (req: AuthenticatedRequest, res) => {
  const { username, currency } = req.body;
  const updated = db.updateUserProfile(req.userId!, { username, currency });
  res.json({ user: updated });
});

// Overview / Dashboard Summary
app.get('/api/overview', authMiddleware, (req: AuthenticatedRequest, res) => {
  const now = new Date();
  const month = req.query.month ? parseInt(req.query.month as string, 10) : now.getMonth() + 1;
  const year = req.query.year ? parseInt(req.query.year as string, 10) : now.getFullYear();

  const context = buildUserFinancialContext(req.userId!, month, year);

  // Daily Expenses Calculation
  const allExpenses = db.getExpenses(req.userId!);
  const pad = (n: number) => n.toString().padStart(2, '0');
  const yyyyMm = `${year}-${pad(month)}`;
  const monthExpenses = allExpenses.filter((e) => e.date.startsWith(yyyyMm));

  // Group by day
  const dailyMap: Record<string, number> = {};
  monthExpenses.forEach((e) => {
    dailyMap[e.date] = (dailyMap[e.date] || 0) + e.amount;
  });
  const dailyExpenses = Object.entries(dailyMap)
    .map(([date, amount]) => ({ date, amount }))
    .sort((a, b) => a.date.localeCompare(b.date));

  // Today and weekly expenses
  const todayStr = `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`;
  const todayExpense = dailyMap[todayStr] || 0;

  const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 3600 * 1000);
  const weeklyExpense = allExpenses
    .filter((e) => new Date(e.date) >= sevenDaysAgo && new Date(e.date) <= now)
    .reduce((sum, e) => sum + e.amount, 0);

  // Highest Expense Category
  let highestExpenseCategory = { category: 'None', amount: 0 };
  for (const [cat, amt] of Object.entries(context.categories)) {
    if (amt > highestExpenseCategory.amount) {
      highestExpenseCategory = { category: cat, amount: amt };
    }
  }

  // Monthly trends for past 6 months
  const monthlyTrend: { month: string; income: number; expenses: number }[] = [];
  for (let i = 5; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const mStr = `${d.getFullYear()}-${pad(d.getMonth() + 1)}`;
    const label = d.toLocaleString('default', { month: 'short' });
    const inc = db.getIncomes(req.userId!).filter((x) => x.date.startsWith(mStr)).reduce((s, x) => s + x.amount, 0);
    const exp = db.getExpenses(req.userId!).filter((x) => x.date.startsWith(mStr)).reduce((s, x) => s + x.amount, 0);
    monthlyTrend.push({ month: label, income: inc, expenses: exp });
  }

  const remainingBudget = context.budget > 0 ? context.budget - context.monthlyExpenses : 0;
  const budgetUtilizationPct = context.budget > 0 ? Math.round((context.monthlyExpenses / context.budget) * 100) : 0;

  res.json({
    currency: context.currency,
    month,
    year,
    totalIncome: context.monthlyIncome,
    totalExpenses: context.monthlyExpenses,
    netSavings: context.monthlySavings,
    overallBudget: context.budget,
    remainingBudget,
    budgetUtilizationPct,
    todayExpense,
    weeklyExpense,
    highestExpenseCategory,
    expensesByCategory: context.categories,
    categoryBudgets: context.categoryBudgets,
    dailyExpenses,
    monthlyTrend,
  });
});

// Income Routes
app.get('/api/income', authMiddleware, (req: AuthenticatedRequest, res) => {
  const incomes = db.getIncomes(req.userId!);
  res.json({ incomes });
});

app.post('/api/income', authMiddleware, (req: AuthenticatedRequest, res) => {
  const { amount, category, source, date, description } = req.body;
  if (!amount || amount <= 0 || !category || !source || !date) {
    res.status(400).json({ error: 'Valid amount, category, source, and date are required.' });
    return;
  }
  const item = db.addIncome(req.userId!, {
    amount: parseFloat(amount),
    category,
    source,
    date,
    description: description || '',
  });
  res.status(201).json({ income: item });
});

app.put('/api/income/:id', authMiddleware, (req: AuthenticatedRequest, res) => {
  const { amount, category, source, date, description } = req.body;
  const updated = db.updateIncome(req.userId!, req.params.id, {
    amount: amount !== undefined ? parseFloat(amount) : undefined,
    category,
    source,
    date,
    description,
  });
  if (!updated) {
    res.status(404).json({ error: 'Income entry not found.' });
    return;
  }
  res.json({ income: updated });
});

app.delete('/api/income/:id', authMiddleware, (req: AuthenticatedRequest, res) => {
  const deleted = db.deleteIncome(req.userId!, req.params.id);
  if (!deleted) {
    res.status(404).json({ error: 'Income entry not found.' });
    return;
  }
  res.json({ success: true });
});

// Expenses Routes
app.get('/api/expenses', authMiddleware, (req: AuthenticatedRequest, res) => {
  let expenses = db.getExpenses(req.userId!);
  const { category, search, month, year } = req.query;

  if (category && typeof category === 'string' && category !== 'All') {
    expenses = expenses.filter((e) => e.category.toLowerCase() === category.toLowerCase());
  }

  if (search && typeof search === 'string') {
    const q = search.toLowerCase();
    expenses = expenses.filter((e) => e.category.toLowerCase().includes(q) || (e.description && e.description.toLowerCase().includes(q)));
  }

  if (month && year) {
    const pad = (n: number) => n.toString().padStart(2, '0');
    const yyyyMm = `${year}-${pad(parseInt(month as string, 10))}`;
    expenses = expenses.filter((e) => e.date.startsWith(yyyyMm));
  }

  res.json({ expenses });
});

app.post('/api/expenses', authMiddleware, (req: AuthenticatedRequest, res) => {
  const { amount, category, date, description } = req.body;
  if (!amount || amount <= 0 || !category || !date) {
    res.status(400).json({ error: 'Valid amount, category, and date are required.' });
    return;
  }
  const item = db.addExpense(req.userId!, {
    amount: parseFloat(amount),
    category,
    date,
    description: description || '',
  });
  res.status(201).json({ expense: item });
});

app.put('/api/expenses/:id', authMiddleware, (req: AuthenticatedRequest, res) => {
  const { amount, category, date, description } = req.body;
  const updated = db.updateExpense(req.userId!, req.params.id, {
    amount: amount !== undefined ? parseFloat(amount) : undefined,
    category,
    date,
    description,
  });
  if (!updated) {
    res.status(404).json({ error: 'Expense entry not found.' });
    return;
  }
  res.json({ expense: updated });
});

app.delete('/api/expenses/:id', authMiddleware, (req: AuthenticatedRequest, res) => {
  const deleted = db.deleteExpense(req.userId!, req.params.id);
  if (!deleted) {
    res.status(404).json({ error: 'Expense entry not found.' });
    return;
  }
  res.json({ success: true });
});

// Budget Routes
app.get('/api/budget', authMiddleware, (req: AuthenticatedRequest, res) => {
  const now = new Date();
  const month = req.query.month ? parseInt(req.query.month as string, 10) : now.getMonth() + 1;
  const year = req.query.year ? parseInt(req.query.year as string, 10) : now.getFullYear();

  const budgets = db.getBudgets(req.userId!, month, year);

  // Also include actual spend for each category to compare
  const pad = (n: number) => n.toString().padStart(2, '0');
  const yyyyMm = `${year}-${pad(month)}`;
  const monthExpenses = db.getExpenses(req.userId!).filter((e) => e.date.startsWith(yyyyMm));

  const categorySpend: Record<string, number> = {};
  let totalSpend = 0;
  monthExpenses.forEach((e) => {
    categorySpend[e.category] = (categorySpend[e.category] || 0) + e.amount;
    totalSpend += e.amount;
  });

  const comparisons = budgets.map((b) => {
    const actual = b.category.toLowerCase() === 'overall' ? totalSpend : categorySpend[b.category] || 0;
    const remaining = b.amount - actual;
    const utilizationPct = b.amount > 0 ? Math.round((actual / b.amount) * 100) : 0;
    let status: 'within' | 'warning' | 'over' = 'within';
    if (utilizationPct > 100) status = 'over';
    else if (utilizationPct >= 80) status = 'warning';

    return {
      ...b,
      actual,
      remaining,
      utilizationPct,
      status,
    };
  });

  res.json({
    budgets: comparisons,
    month,
    year,
    totalExpenses: totalSpend,
  });
});

app.post('/api/budget', authMiddleware, (req: AuthenticatedRequest, res) => {
  const { category, amount, month, year } = req.body;
  if (!category || amount === undefined || amount < 0 || !month || !year) {
    res.status(400).json({ error: 'Category, non-negative amount, month, and year are required.' });
    return;
  }
  const budget = db.setBudget(req.userId!, category, parseFloat(amount), parseInt(month, 10), parseInt(year, 10));
  res.status(201).json({ budget });
});

app.delete('/api/budget/:id', authMiddleware, (req: AuthenticatedRequest, res) => {
  const deleted = db.deleteBudget(req.userId!, req.params.id);
  if (!deleted) {
    res.status(404).json({ error: 'Budget item not found.' });
    return;
  }
  res.json({ success: true });
});

// Savings Goals Routes
app.get('/api/savings', authMiddleware, (req: AuthenticatedRequest, res) => {
  const goals = db.getSavingsGoals(req.userId!);
  const goalsWithProgress = goals.map((g) => {
    const progressPct = g.target_amount > 0 ? Math.min(100, Math.round((g.current_amount / g.target_amount) * 100)) : 0;
    const remaining = Math.max(0, g.target_amount - g.current_amount);
    return {
      ...g,
      progressPct,
      remaining,
    };
  });
  res.json({ goals: goalsWithProgress });
});

app.post('/api/savings', authMiddleware, (req: AuthenticatedRequest, res) => {
  const { goal_name, target_amount, current_amount, deadline, category } = req.body;
  if (!goal_name || !target_amount || target_amount <= 0 || !deadline) {
    res.status(400).json({ error: 'Goal name, positive target amount, and deadline are required.' });
    return;
  }
  const goal = db.addSavingsGoal(req.userId!, {
    goal_name,
    target_amount: parseFloat(target_amount),
    current_amount: current_amount ? parseFloat(current_amount) : 0,
    deadline,
    category: category || 'Savings',
  });
  res.status(201).json({ goal });
});

app.put('/api/savings/:id', authMiddleware, (req: AuthenticatedRequest, res) => {
  const { goal_name, target_amount, current_amount, add_contribution, deadline, category } = req.body;
  const existing = db.getSavingsGoals(req.userId!).find((g) => g.id === req.params.id);
  if (!existing) {
    res.status(404).json({ error: 'Savings goal not found.' });
    return;
  }

  let newCurrent = existing.current_amount;
  if (add_contribution !== undefined) {
    newCurrent += parseFloat(add_contribution);
  } else if (current_amount !== undefined) {
    newCurrent = parseFloat(current_amount);
  }

  const updated = db.updateSavingsGoal(req.userId!, req.params.id, {
    goal_name,
    target_amount: target_amount !== undefined ? parseFloat(target_amount) : undefined,
    current_amount: Math.max(0, newCurrent),
    deadline,
    category,
  });

  res.json({ goal: updated });
});

app.delete('/api/savings/:id', authMiddleware, (req: AuthenticatedRequest, res) => {
  const deleted = db.deleteSavingsGoal(req.userId!, req.params.id);
  if (!deleted) {
    res.status(404).json({ error: 'Savings goal not found.' });
    return;
  }
  res.json({ success: true });
});

// AI Financial Advisor Endpoints
app.post('/api/ai/analyze', authMiddleware, async (req: AuthenticatedRequest, res) => {
  try {
    const month = req.body.month ? parseInt(req.body.month, 10) : undefined;
    const year = req.body.year ? parseInt(req.body.year, 10) : undefined;
    const context = buildUserFinancialContext(req.userId!, month, year);

    const analysis = await generateAIAnalysis(context);
    res.json({ analysis });
  } catch (err: any) {
    console.error('Error generating AI analysis:', err);
    res.status(500).json({ error: 'Failed to generate financial analysis. Please try again.' });
  }
});

app.get('/api/ai/chat', authMiddleware, (req: AuthenticatedRequest, res) => {
  const history = db.getChatHistory(req.userId!);
  res.json({ history });
});

app.post('/api/ai/chat', authMiddleware, async (req: AuthenticatedRequest, res) => {
  const { message } = req.body;
  if (!message || typeof message !== 'string' || !message.trim()) {
    res.status(400).json({ error: 'Message content is required.' });
    return;
  }

  try {
    const userMsg = db.addChatMessage(req.userId!, 'user', message.trim());
    const context = buildUserFinancialContext(req.userId!);
    const history = db.getChatHistory(req.userId!);

    const assistantReply = await askFinancialAdvisorChat(
      context,
      history.map((m) => ({ role: m.role, content: m.content })),
      message.trim()
    );

    const botMsg = db.addChatMessage(req.userId!, 'assistant', assistantReply);
    res.json({ userMessage: userMsg, botMessage: botMsg });
  } catch (err: any) {
    console.error('Chat bot error:', err);
    res.status(500).json({ error: 'Advisor service encountered an error.' });
  }
});

app.post('/api/ai/chat/clear', authMiddleware, (req: AuthenticatedRequest, res) => {
  db.clearChatHistory(req.userId!);
  res.json({ success: true });
});

// Reports Endpoints
app.get('/api/reports', authMiddleware, (req: AuthenticatedRequest, res) => {
  const reports = db.getReports(req.userId!);
  res.json({ reports });
});

app.post('/api/reports/generate', authMiddleware, async (req: AuthenticatedRequest, res) => {
  const now = new Date();
  const month = req.body.month ? parseInt(req.body.month, 10) : now.getMonth() + 1;
  const year = req.body.year ? parseInt(req.body.year, 10) : now.getFullYear();

  const context = buildUserFinancialContext(req.userId!, month, year);

  let highestCat = 'None';
  let highestAmt = 0;
  for (const [cat, amt] of Object.entries(context.categories)) {
    if (amt > highestAmt) {
      highestCat = cat;
      highestAmt = amt;
    }
  }

  // Generate quick summary from AI or rule-based
  let aiSummary = `Summary for ${month}/${year}: Total Income of ${context.currency}${context.monthlyIncome.toLocaleString()}, Total Expenses of ${context.currency}${context.monthlyExpenses.toLocaleString()}, resulting in Net Savings of ${context.currency}${context.monthlySavings.toLocaleString()}. Primary expense category was ${highestCat} (${context.currency}${highestAmt.toLocaleString()}).`;

  try {
    const aiAnalysis = await generateAIAnalysis(context);
    aiSummary = `${aiAnalysis.spending_summary} | Top action: ${aiAnalysis.next_month_action_plan[0] || 'Keep expenses tracked'}`;
  } catch (e) {
    // keep default summary
  }

  const report = db.saveReport(req.userId!, {
    month,
    year,
    income: context.monthlyIncome,
    expenses: context.monthlyExpenses,
    savings: context.monthlySavings,
    highest_category: highestCat,
    highest_category_amount: highestAmt,
    ai_summary: aiSummary,
  });

  res.status(201).json({ report });
});

// Demo Data Reset
app.post('/api/demo/reset', authMiddleware, (req: AuthenticatedRequest, res) => {
  db.resetUserData(req.userId!);
  res.json({ success: true, message: 'Ledger successfully refreshed with standard test data.' });
});

// Project Source Code & Viva Guide
app.get('/api/project/files', (req, res) => {
  res.json({ files: PYTHON_PROJECT_FILES });
});

// Start Server with Vite Middleware or Static Assets
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Personal Finance Advisor Bot running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
