import React, { useState, useEffect } from 'react';
import { Navbar, ActiveTab } from './components/Navbar';
import { DashboardView } from './components/DashboardView';
import { IncomeView } from './components/IncomeView';
import { ExpenseView } from './components/ExpenseView';
import { BudgetView } from './components/BudgetView';
import { SavingsView } from './components/SavingsView';
import { AdvisorView } from './components/AdvisorView';
import { ReportsView } from './components/ReportsView';
import { ProfileView } from './components/ProfileView';
import { ProjectDocsModal } from './components/ProjectDocsModal';
import { AuthModal } from './components/AuthModal';
import { api, getStoredToken } from './api';
import { User } from './types';
import { ShieldCheck, Bot, Sparkles, BookOpen } from 'lucide-react';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [isInitializing, setIsInitializing] = useState<boolean>(true);
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');

  // Overview Data
  const [overview, setOverview] = useState<any>(null);
  const [loadingOverview, setLoadingOverview] = useState<boolean>(false);

  // Modals & Triggers
  const [isProjectDocsOpen, setIsProjectDocsOpen] = useState<boolean>(false);
  const [isResetting, setIsResetting] = useState<boolean>(false);
  const [feedbackBanner, setFeedbackBanner] = useState<string | null>(null);

  // Initialize Auth & Data
  useEffect(() => {
    const initApp = async () => {
      try {
        const token = getStoredToken();
        if (token) {
          const res = await api.me();
          setUser(res.user);
        } else {
          // Auto-login with default demo user for frictionless instant preview experience!
          try {
            const res = await api.login('alex@student.edu', 'demo123');
            setUser(res.user);
          } catch (e) {
            // Leave as null if failed, AuthModal will show
          }
        }
      } catch (err) {
        console.warn('Initial session check failed, please sign in.');
      } finally {
        setIsInitializing(false);
      }
    };

    initApp();
  }, []);

  const fetchOverview = async () => {
    if (!user) return;
    try {
      setLoadingOverview(true);
      const data = await api.getOverview();
      setOverview(data);
    } catch (err: any) {
      console.error('Failed to load financial overview:', err);
    } finally {
      setLoadingOverview(false);
    }
  };

  useEffect(() => {
    if (user) {
      fetchOverview();
    }
  }, [user]);

  const handleResetDemoData = async () => {
    try {
      setIsResetting(true);
      await api.resetDemoData();
      const meRes = await api.me();
      setUser(meRes.user);
      await fetchOverview();
      setFeedbackBanner('Sample student financial ledger data has been successfully re-seeded.');
      setTimeout(() => setFeedbackBanner(null), 4000);
    } catch (err: any) {
      alert(err.message || 'Failed to reset demo data.');
    } finally {
      setIsResetting(false);
    }
  };

  const handleLogout = async () => {
    await api.logout();
    setUser(null);
    setOverview(null);
  };

  if (isInitializing) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center text-slate-600 space-y-3">
        <div className="w-8 h-8 border-3 border-emerald-600/20 border-t-emerald-600 rounded-full animate-spin"></div>
        <p className="text-sm font-medium text-slate-600">Loading your finances...</p>
      </div>
    );
  }

  const currency = user?.currency || '₹';

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col">
      {/* Auth Barrier */}
      {!user && (
        <AuthModal
          onLoginSuccess={(loggedUser) => {
            setUser(loggedUser);
            fetchOverview();
          }}
        />
      )}

      {/* Top Main Navigation Bar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        user={user}
        onLogout={handleLogout}
        onOpenProjectDocs={() => setIsProjectDocsOpen(true)}
        onResetDemoData={handleResetDemoData}
        isResetting={isResetting}
      />

      {/* Temporary Feedback Notification */}
      {feedbackBanner && (
        <div className="bg-emerald-50 border-b border-emerald-200 text-emerald-800 px-4 py-2.5 text-center text-xs font-medium transition-all flex items-center justify-center space-x-2">
          <Sparkles className="w-4 h-4 text-emerald-600" />
          <span>{feedbackBanner}</span>
        </div>
      )}

      {/* Main Content Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeTab === 'dashboard' && (
          <DashboardView
            overview={overview}
            currency={currency}
            onNavigate={(tab) => setActiveTab(tab)}
            onRefresh={fetchOverview}
            isLoading={loadingOverview}
          />
        )}

        {activeTab === 'income' && (
          <IncomeView currency={currency} onRefreshOverview={fetchOverview} />
        )}

        {activeTab === 'expenses' && (
          <ExpenseView currency={currency} onRefreshOverview={fetchOverview} />
        )}

        {activeTab === 'budget' && (
          <BudgetView
            currency={currency}
            onRefreshOverview={fetchOverview}
            onNavigateToAdvisor={() => setActiveTab('advisor')}
          />
        )}

        {activeTab === 'savings' && (
          <SavingsView
            currency={currency}
            netSavings={overview?.netSavings || 0}
            onRefreshOverview={fetchOverview}
          />
        )}

        {activeTab === 'advisor' && (
          <AdvisorView currency={currency} onRefreshOverview={fetchOverview} />
        )}

        {activeTab === 'reports' && <ReportsView currency={currency} />}

        {activeTab === 'profile' && (
          <ProfileView
            user={user}
            onUpdateUser={(updated) => setUser(updated)}
            onResetDemoData={handleResetDemoData}
            isResetting={isResetting}
          />
        )}
      </main>

      {/* College Project & Viva Guide Modal */}
      <ProjectDocsModal
        isOpen={isProjectDocsOpen}
        onClose={() => setIsProjectDocsOpen(false)}
      />

      {/* Footer (Hidden during Print) */}
      <footer className="print:hidden border-t border-slate-200 bg-white py-6 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center space-x-2">
            <span className="font-semibold text-slate-700">Personal Finance</span>
            <span>•</span>
            <span>Income, Expense & Budget Tracker with AI Advisor</span>
          </div>

          <div className="flex items-center space-x-4">
            <button
              onClick={() => setIsProjectDocsOpen(true)}
              className="text-slate-600 hover:text-slate-900 font-medium flex items-center gap-1.5 transition-colors"
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>Project Guide & Python Code</span>
            </button>
            <span>•</span>
            <span className="flex items-center gap-1.5 text-emerald-700 font-medium">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block"></span>
              <span>Gemini AI Connected</span>
            </span>
          </div>
        </div>
      </footer>
    </div>
  );
}
