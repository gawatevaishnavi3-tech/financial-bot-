import {
  User,
  Income,
  Expense,
  Budget,
  SavingsGoal,
  FinancialReport,
  AIAnalysisResult,
  ChatMessage,
  FinancialOverview,
} from './types';

const TOKEN_KEY = 'pfab_auth_token';

export function getStoredToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

export function setStoredToken(token: string) {
  localStorage.setItem(TOKEN_KEY, token);
}

export function clearStoredToken() {
  localStorage.removeItem(TOKEN_KEY);
}

async function request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const token = getStoredToken();
  const headers = new Headers(options.headers || {});
  headers.set('Content-Type', 'application/json');

  if (token) {
    headers.set('Authorization', `Bearer ${token}`);
  }

  const response = await fetch(endpoint, {
    ...options,
    headers,
  });

  const data = await response.json().catch(() => ({}));

  if (!response.ok) {
    const errorMsg = data.error || `HTTP Error ${response.status}: ${response.statusText}`;
    throw new Error(errorMsg);
  }

  return data as T;
}

export const api = {
  // Auth
  async login(email: string, password: string): Promise<{ user: User; token: string }> {
    const res = await request<{ user: User; token: string }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
    setStoredToken(res.token);
    return res;
  },

  async register(username: string, email: string, password: string, currency = '₹'): Promise<{ user: User; token: string }> {
    const res = await request<{ user: User; token: string }>('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify({ username, email, password, currency }),
    });
    setStoredToken(res.token);
    return res;
  },

  async me(): Promise<{ user: User }> {
    return request<{ user: User }>('/api/auth/me');
  },

  async logout(): Promise<void> {
    try {
      await request('/api/auth/logout', { method: 'POST' });
    } finally {
      clearStoredToken();
    }
  },

  async updateProfile(updates: { username?: string; currency?: string }): Promise<{ user: User }> {
    return request<{ user: User }>('/api/auth/profile', {
      method: 'PUT',
      body: JSON.stringify(updates),
    });
  },

  // Overview / Dashboard
  async getOverview(month?: number, year?: number): Promise<FinancialOverview & {
    currency: string;
    month: number;
    year: number;
    todayExpense: number;
    weeklyExpense: number;
    categoryBudgets: Record<string, number>;
  }> {
    const params = new URLSearchParams();
    if (month) params.set('month', month.toString());
    if (year) params.set('year', year.toString());
    return request(`/api/overview?${params.toString()}`);
  },

  // Income
  async getIncomes(): Promise<{ incomes: Income[] }> {
    return request('/api/income');
  },

  async addIncome(income: Omit<Income, 'id' | 'user_id' | 'created_at'>): Promise<{ income: Income }> {
    return request('/api/income', {
      method: 'POST',
      body: JSON.stringify(income),
    });
  },

  async updateIncome(id: string, updates: Partial<Income>): Promise<{ income: Income }> {
    return request(`/api/income/${id}`, {
      method: 'PUT',
      body: JSON.stringify(updates),
    });
  },

  async deleteIncome(id: string): Promise<{ success: boolean }> {
    return request(`/api/income/${id}`, {
      method: 'DELETE',
    });
  },

  // Expenses
  async getExpenses(filters?: { category?: string; search?: string; month?: number; year?: number }): Promise<{ expenses: Expense[] }> {
    const params = new URLSearchParams();
    if (filters?.category) params.set('category', filters.category);
    if (filters?.search) params.set('search', filters.search);
    if (filters?.month) params.set('month', filters.month.toString());
    if (filters?.year) params.set('year', filters.year.toString());
    return request(`/api/expenses?${params.toString()}`);
  },

  async addExpense(expense: Omit<Expense, 'id' | 'user_id' | 'created_at'>): Promise<{ expense: Expense }> {
    return request('/api/expenses', {
      method: 'POST',
      body: JSON.stringify(expense),
    });
  },

  async updateExpense(id: string, updates: Partial<Expense>): Promise<{ expense: Expense }> {
    return request(`/api/expenses/${id}`, {
      method: 'PUT',
      body: JSON.stringify(updates),
    });
  },

  async deleteExpense(id: string): Promise<{ success: boolean }> {
    return request(`/api/expenses/${id}`, {
      method: 'DELETE',
    });
  },

  // Budget
  async getBudgets(month?: number, year?: number): Promise<{
    budgets: (Budget & { actual: number; remaining: number; utilizationPct: number; status: 'within' | 'warning' | 'over' })[];
    month: number;
    year: number;
    totalExpenses: number;
  }> {
    const params = new URLSearchParams();
    if (month) params.set('month', month.toString());
    if (year) params.set('year', year.toString());
    return request(`/api/budget?${params.toString()}`);
  },

  async setBudget(category: string, amount: number, month: number, year: number): Promise<{ budget: Budget }> {
    return request('/api/budget', {
      method: 'POST',
      body: JSON.stringify({ category, amount, month, year }),
    });
  },

  async deleteBudget(id: string): Promise<{ success: boolean }> {
    return request(`/api/budget/${id}`, {
      method: 'DELETE',
    });
  },

  // Savings Goals
  async getSavingsGoals(): Promise<{ goals: (SavingsGoal & { progressPct: number; remaining: number })[] }> {
    return request('/api/savings');
  },

  async addSavingsGoal(goal: Omit<SavingsGoal, 'id' | 'user_id' | 'created_at'>): Promise<{ goal: SavingsGoal }> {
    return request('/api/savings', {
      method: 'POST',
      body: JSON.stringify(goal),
    });
  },

  async updateSavingsGoal(id: string, updates: Partial<SavingsGoal> & { add_contribution?: number }): Promise<{ goal: SavingsGoal }> {
    return request(`/api/savings/${id}`, {
      method: 'PUT',
      body: JSON.stringify(updates),
    });
  },

  async deleteSavingsGoal(id: string): Promise<{ success: boolean }> {
    return request(`/api/savings/${id}`, {
      method: 'DELETE',
    });
  },

  // AI Advisor
  async getAIAnalysis(month?: number, year?: number): Promise<{ analysis: AIAnalysisResult }> {
    return request('/api/ai/analyze', {
      method: 'POST',
      body: JSON.stringify({ month, year }),
    });
  },

  async getAIChatHistory(): Promise<{ history: ChatMessage[] }> {
    return request('/api/ai/chat');
  },

  async sendAIChatMessage(message: string): Promise<{ userMessage: ChatMessage; botMessage: ChatMessage }> {
    return request('/api/ai/chat', {
      method: 'POST',
      body: JSON.stringify({ message }),
    });
  },

  async clearAIChatHistory(): Promise<{ success: boolean }> {
    return request('/api/ai/chat/clear', { method: 'POST' });
  },

  // Reports
  async getReports(): Promise<{ reports: FinancialReport[] }> {
    return request('/api/reports');
  },

  async generateReport(month?: number, year?: number): Promise<{ report: FinancialReport }> {
    return request('/api/reports/generate', {
      method: 'POST',
      body: JSON.stringify({ month, year }),
    });
  },

  // Demo
  async resetDemoData(): Promise<{ success: boolean; message: string }> {
    return request('/api/demo/reset', { method: 'POST' });
  },

  async getProjectFiles(): Promise<{ files: any[] }> {
    return request('/api/project/files');
  },
};
