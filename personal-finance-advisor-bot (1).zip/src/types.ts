export interface User {
  id: string;
  username: string;
  email: string;
  currency: string;
  created_at: string;
}

export interface Income {
  id: string;
  user_id: string;
  amount: number;
  category: string;
  source: string;
  date: string;
  description?: string;
  created_at: string;
}

export interface Expense {
  id: string;
  user_id: string;
  amount: number;
  category: string;
  date: string;
  description?: string;
  created_at: string;
}

export interface Budget {
  id: string;
  user_id: string;
  category: string; // 'Overall' or specific category
  amount: number;
  month: number; // 1-12
  year: number;
  created_at: string;
}

export interface SavingsGoal {
  id: string;
  user_id: string;
  goal_name: string;
  target_amount: number;
  current_amount: number;
  deadline: string;
  category?: string;
  created_at: string;
}

export interface FinancialReport {
  id: string;
  user_id: string;
  month: number;
  year: number;
  income: number;
  expenses: number;
  savings: number;
  highest_category: string;
  highest_category_amount: number;
  ai_summary?: string;
  created_at: string;
}

export interface AIAnalysisResult {
  spending_summary: string;
  overspending_categories: {
    category: string;
    spent: number;
    budget: number;
    excess: number;
    severity: 'moderate' | 'high' | 'critical';
  }[];
  recommended_budget: {
    category: string;
    suggested_limit: number;
    rationale: string;
  }[];
  savings_suggestions: string[];
  cost_cutting_suggestions: string[];
  emergency_fund_suggestion: {
    current_estimate: number;
    target_months: number;
    recommended_target: number;
    steps_to_reach: string;
  };
  next_month_action_plan: string[];
  financial_health_score: number; // 0-100
  financial_health_grade: 'A' | 'B' | 'C' | 'D' | 'F';
  generated_at: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
}

export interface FinancialOverview {
  totalIncome: number;
  totalExpenses: number;
  netSavings: number;
  overallBudget: number;
  remainingBudget: number;
  budgetUtilizationPct: number;
  highestExpenseCategory: {
    category: string;
    amount: number;
  };
  expensesByCategory: Record<string, number>;
  dailyExpenses: { date: string; amount: number }[];
  monthlyTrend: { month: string; income: number; expenses: number }[];
}
