import React, { useState } from 'react';
import {
  X,
  BookOpen,
  Code2,
  HelpCircle,
  CheckSquare,
  Copy,
  Check,
  Layers,
  Sparkles,
} from 'lucide-react';
import { PYTHON_PROJECT_FILES } from '../../server/pythonProjectFiles';

interface ProjectDocsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const VIVA_QUESTIONS = [
  {
    q: '1. What is the architecture and core objective of Personal Finance Advisor Bot?',
    a: 'Personal Finance Advisor Bot is a full-stack FinTech application combining a deterministic financial ledger (tracking income, categorized expenses, budget caps, and savings goals) with a contextual AI advisor powered by Google Gemini. The architecture strictly separates numeric calculations (exact totals, budget utilization, savings rates) from LLM generative advice (spending habit audits, cost-cutting recommendations, emergency fund strategies) to avoid hallucinated calculations.',
  },
  {
    q: '2. How are mathematical financial calculations kept accurate if LLMs are known to hallucinate math?',
    a: 'Deterministic computation is strictly performed by the backend service and relational store. Financial formulas like Total Savings = Income - Expenses, Utilization Rate = (Spent / Budget) * 100, and Remaining Budget = Budget - Expenses are computed deterministically in code before passing the verified JSON summary to Gemini as system context. The LLM only evaluates qualitative insights and advice based on already verified figures.',
  },
  {
    q: '3. What database schema and ORM are used for data persistence?',
    a: 'In the Python/Flask stack, SQLAlchemy ORM is used with an SQLite database (easily switchable to PostgreSQL via DATABASE_URL). The schema includes five normalized tables: User (credentials, currency), Income (source, category, amount, date), Expense (category, amount, date, description), Budget (category, monthly cap, period), SavingsGoal (target, accumulated amount, deadline), and FinancialReport (monthly snapshot archives).',
  },
  {
    q: '4. How is the Google Gemini API integrated and authenticated?',
    a: 'We use the official @google/genai TypeScript SDK and Python google-genai SDK. Calls are strictly made server-side to protect GEMINI_API_KEY from exposure in client code. We use gemini-2.5-flash with low temperature for structured JSON output during audits, and moderate temperature for natural, supportive conversation during financial advisor chats.',
  },
  {
    q: '5. How does the application detect and alert for overspending?',
    a: 'The backend evaluates monthly categorized expenditures against set budget limits. When spending reaches 80% to 100%, the system flags a "Near Limit" warning. When expenditure exceeds 100%, an "Over Budget" status is triggered, calculating the exact excess burn amount. Gemini then generates targeted cost-cutting suggestions for that specific category.',
  },
  {
    q: '6. What security practices are implemented in the project?',
    a: '1) Password hashing using modern cryptographic standards (bcrypt/werkzeug). 2) Bearer token and session-based authentication. 3) Server-side proxying of all AI keys so API credentials are never bundled into client scripts. 4) Strict prompt containment to prevent prompt injection and keep the bot focused solely on financial advising.',
  },
  {
    q: '7. How does the Savings Goal tracking mechanism operate?',
    a: 'Users establish distinct savings objectives (e.g., Emergency Reserve, Tech Upgrade). Each goal records target amount, current deposit balance, and deadline. The system dynamically computes progress percentage ((current / target) * 100) and remaining deficit, and provides instant quick-deposit actions.',
  },
  {
    q: '8. How does the Monthly Summary and Report generation work?',
    a: 'At the conclusion of each billing cycle or on demand, the system aggregates all income streams, itemized expenses, and budget variances for the month. It generates an official PDF-ready statement featuring key metrics, category breakdown tables, and an AI executive commentary.',
  },
  {
    q: '9. Can this application be hosted and demonstrated publicly for viva exams?',
    a: 'Yes. In addition to running directly in Google AI Studio Cloud Run containers, the Python Flask backend can be run locally (`python app.py`) and tunneled through Ngrok (`ngrok http 5000`) to generate a live HTTPS link accessible from examiners’ mobile phones or laptops.',
  },
  {
    q: '10. What are future FinTech extensions for this project?',
    a: '1) Bank account aggregator integration via Account Aggregator / Plaid APIs. 2) SMS/email automated transaction parsing using on-device regex/NLP. 3) Recurring subscription leak detection. 4) Export to CSV/Excel for tax compliance.',
  },
];

export const ProjectDocsModal: React.FC<ProjectDocsModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'python-code' | 'viva' | 'architecture' | 'checklist'>('viva');
  const [selectedFileIdx, setSelectedFileIdx] = useState<number>(0);
  const [copied, setCopied] = useState<boolean>(false);

  if (!isOpen) return null;

  const currentFile = PYTHON_PROJECT_FILES[selectedFileIdx] || PYTHON_PROJECT_FILES[0];

  const handleCopyCode = () => {
    navigator.clipboard.writeText(currentFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs">
      <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-5xl h-[85vh] flex flex-col shadow-xl overflow-hidden">
        {/* Modal Header */}
        <div className="p-4 sm:px-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/60">
          <div className="flex items-center space-x-3">
            <div className="p-2 rounded-lg bg-slate-100 text-slate-800">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-semibold text-slate-900 flex items-center gap-2">
                Project Documentation & Python Source
              </h2>
              <p className="text-xs text-slate-500">
                Viva exam guide, Python Flask source files, database schema, and test checklist.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center space-x-1 px-6 border-b border-slate-100 bg-white text-xs overflow-x-auto">
          <button
            onClick={() => setActiveTab('viva')}
            className={`py-3 px-3 font-medium border-b-2 flex items-center space-x-1.5 transition-colors whitespace-nowrap ${
              activeTab === 'viva'
                ? 'border-slate-900 text-slate-900'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <HelpCircle className="w-4 h-4" />
            <span>Viva Q&A (Top 10)</span>
          </button>

          <button
            onClick={() => setActiveTab('python-code')}
            className={`py-3 px-3 font-medium border-b-2 flex items-center space-x-1.5 transition-colors whitespace-nowrap ${
              activeTab === 'python-code'
                ? 'border-slate-900 text-slate-900'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Code2 className="w-4 h-4" />
            <span>Python Flask Source ({PYTHON_PROJECT_FILES.length} Files)</span>
          </button>

          <button
            onClick={() => setActiveTab('architecture')}
            className={`py-3 px-3 font-medium border-b-2 flex items-center space-x-1.5 transition-colors whitespace-nowrap ${
              activeTab === 'architecture'
                ? 'border-slate-900 text-slate-900'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>Architecture & Schemas</span>
          </button>

          <button
            onClick={() => setActiveTab('checklist')}
            className={`py-3 px-3 font-medium border-b-2 flex items-center space-x-1.5 transition-colors whitespace-nowrap ${
              activeTab === 'checklist'
                ? 'border-slate-900 text-slate-900'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <CheckSquare className="w-4 h-4" />
            <span>Testing Checklist</span>
          </button>
        </div>

        {/* Tab Content Area */}
        <div className="flex-1 overflow-y-auto p-6 bg-slate-50/50">
          {/* TAB 1: VIVA QUESTIONS */}
          {activeTab === 'viva' && (
            <div className="space-y-4 max-w-4xl mx-auto">
              <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs">
                <strong>Viva Note:</strong> Examiners frequently examine how AI recommendations are grounded, why raw LLMs must not do direct arithmetic, and how the database tables are normalized.
              </div>

              <div className="space-y-3">
                {VIVA_QUESTIONS.map((item, idx) => (
                  <div
                    key={idx}
                    className="p-4 rounded-xl bg-white border border-slate-200/80 shadow-xs space-y-1.5"
                  >
                    <h4 className="text-xs font-semibold text-slate-900 flex items-center gap-2">
                      <Sparkles className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                      {item.q}
                    </h4>
                    <p className="text-xs text-slate-600 leading-relaxed pl-5.5">{item.a}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 2: PYTHON SOURCE CODE */}
          {activeTab === 'python-code' && (
            <div className="flex flex-col lg:flex-row gap-4 h-full">
              {/* File list sidebar */}
              <div className="w-full lg:w-64 bg-white rounded-xl p-3 border border-slate-200 shadow-xs space-y-1 shrink-0 overflow-y-auto max-h-60 lg:max-h-none">
                <span className="text-[10px] uppercase tracking-wider font-semibold text-slate-400 px-2 py-1 block">
                  Project Files
                </span>
                {PYTHON_PROJECT_FILES.map((f, i) => (
                  <button
                    key={f.path}
                    onClick={() => setSelectedFileIdx(i)}
                    className={`w-full text-left px-3 py-2 rounded-lg text-xs font-mono transition-colors truncate block ${
                      selectedFileIdx === i
                        ? 'bg-slate-900 text-white font-semibold'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                    }`}
                  >
                    {f.filename}
                  </button>
                ))}
              </div>

              {/* Code viewer */}
              <div className="flex-1 bg-slate-950 border border-slate-800 rounded-xl overflow-hidden flex flex-col shadow-xs">
                <div className="p-3 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
                  <span className="font-mono text-xs text-slate-300 font-semibold">{currentFile.path}</span>
                  <button
                    onClick={handleCopyCode}
                    className="flex items-center space-x-1 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs text-white transition-colors"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copied ? 'Copied!' : 'Copy Code'}</span>
                  </button>
                </div>

                <pre className="p-4 font-mono text-xs text-slate-200 overflow-auto flex-1 leading-relaxed whitespace-pre">
                  {currentFile.content}
                </pre>
              </div>
            </div>
          )}

          {/* TAB 3: ARCHITECTURE */}
          {activeTab === 'architecture' && (
            <div className="space-y-6 max-w-4xl mx-auto text-xs">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="p-4 rounded-xl bg-white border border-slate-200 shadow-xs space-y-2">
                  <div className="font-semibold text-slate-900 text-sm">1. Client Tier</div>
                  <p className="text-slate-500 leading-relaxed">
                    Modern responsive interface featuring real-time financial metrics, clean expense tables, budget meters, and advisor chat.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-white border border-slate-200 shadow-xs space-y-2">
                  <div className="font-semibold text-slate-900 text-sm">2. Business Tier</div>
                  <p className="text-slate-500 leading-relaxed">
                    REST API handling CRUD operations, monthly cash flow rollups, budget utilization calculations, and context assembly.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-white border border-slate-200 shadow-xs space-y-2">
                  <div className="font-semibold text-slate-900 text-sm">3. AI & Data Tier</div>
                  <p className="text-slate-500 leading-relaxed">
                    Google Gemini 2.5 Flash SDK for contextual financial guidance, paired with SQLite / PostgreSQL persistence.
                  </p>
                </div>
              </div>

              {/* Data Models Table */}
              <div className="bg-white border border-slate-200 rounded-xl p-4 space-y-3 shadow-xs">
                <h4 className="font-semibold text-slate-900 text-sm">Relational Database Schemas (SQLAlchemy Models)</h4>
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="border-b border-slate-100 text-slate-500 font-semibold uppercase">
                        <th className="py-2 px-3">Table</th>
                        <th className="py-2 px-3">Primary Key</th>
                        <th className="py-2 px-3">Attributes</th>
                        <th className="py-2 px-3">Relationships</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-slate-700">
                      <tr>
                        <td className="py-2.5 px-3 font-mono text-slate-900 font-semibold">User</td>
                        <td className="py-2.5 px-3 font-mono">id (UUID)</td>
                        <td className="py-2.5 px-3">username, email, password_hash, currency</td>
                        <td className="py-2.5 px-3">One-to-Many: Incomes, Expenses, Budgets</td>
                      </tr>
                      <tr>
                        <td className="py-2.5 px-3 font-mono text-slate-900 font-semibold">Income</td>
                        <td className="py-2.5 px-3 font-mono">id (UUID)</td>
                        <td className="py-2.5 px-3">amount, category, source, date, description</td>
                        <td className="py-2.5 px-3">Foreign Key: user_id</td>
                      </tr>
                      <tr>
                        <td className="py-2.5 px-3 font-mono text-slate-900 font-semibold">Expense</td>
                        <td className="py-2.5 px-3 font-mono">id (UUID)</td>
                        <td className="py-2.5 px-3">amount, category, date, description</td>
                        <td className="py-2.5 px-3">Foreign Key: user_id</td>
                      </tr>
                      <tr>
                        <td className="py-2.5 px-3 font-mono text-slate-900 font-semibold">Budget</td>
                        <td className="py-2.5 px-3 font-mono">id (UUID)</td>
                        <td className="py-2.5 px-3">category, amount, month, year</td>
                        <td className="py-2.5 px-3">Foreign Key: user_id</td>
                      </tr>
                      <tr>
                        <td className="py-2.5 px-3 font-mono text-slate-900 font-semibold">SavingsGoal</td>
                        <td className="py-2.5 px-3 font-mono">id (UUID)</td>
                        <td className="py-2.5 px-3">name, target_amount, current_amount, target_date</td>
                        <td className="py-2.5 px-3">Foreign Key: user_id</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: CHECKLIST */}
          {activeTab === 'checklist' && (
            <div className="space-y-4 max-w-3xl mx-auto text-xs">
              <div className="p-4 rounded-xl bg-white border border-slate-200 shadow-xs space-y-3">
                <h4 className="font-semibold text-slate-900 text-sm">Full-Stack Verification Checklist</h4>
                <div className="space-y-2.5">
                  {[
                    'User can register, authenticate, and manage profile preferences.',
                    'Income records can be logged, categorized, edited, and deleted.',
                    'Expenses can be logged across standard categories with daily/weekly rollups.',
                    'Savings rate correctly calculated as: (Income - Expenses) / Income * 100.',
                    'Remaining Budget calculates as: Total Budget - Total Expenses.',
                    'Budget status changes dynamically (Within budget, Near limit, Over budget).',
                    'Savings Goals progress bars increment upon adding deposits.',
                    'AI Financial Advisor generates structured scores, overspending alerts, and action plans.',
                    'Interactive AI Chatbot answers questions using the user’s real financial profile.',
                    'Monthly summary report compiles into a clean printable/PDF document.',
                    'Data reset to sample financial data works seamlessly in one click.',
                  ].map((item, idx) => (
                    <div key={idx} className="flex items-center space-x-2.5 text-slate-700">
                      <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span>{item}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
