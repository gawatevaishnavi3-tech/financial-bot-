import React, { useState, useEffect } from 'react';
import {
  PiggyBank,
  Plus,
  Edit2,
  Trash2,
  Calendar,
  PlusCircle,
  X,
  Target,
  CheckCircle2,
} from 'lucide-react';
import { SavingsGoal } from '../types';
import { api } from '../api';

interface SavingsViewProps {
  currency: string;
  netSavings: number;
  onRefreshOverview?: () => void;
}

export const SavingsView: React.FC<SavingsViewProps> = ({
  currency,
  netSavings,
  onRefreshOverview,
}) => {
  const [goals, setGoals] = useState<SavingsGoal[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  // Modal State
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [editingGoal, setEditingGoal] = useState<SavingsGoal | null>(null);
  const [formData, setFormData] = useState({
    goal_name: '',
    target_amount: '',
    current_amount: '0',
    deadline: '',
  });
  const [formError, setFormError] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // Deposit Contribution State
  const [contributeModal, setContributeModal] = useState<{
    isOpen: boolean;
    goal: SavingsGoal | null;
    amount: string;
  }>({
    isOpen: false,
    goal: null,
    amount: '',
  });

  const fetchGoals = async () => {
    try {
      setLoading(true);
      const res = await api.getSavingsGoals();
      setGoals(res.goals);
    } catch (err: any) {
      console.error('Failed to fetch savings goals:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchGoals();
  }, []);

  const openAddModal = () => {
    setEditingGoal(null);
    setFormData({
      goal_name: '',
      target_amount: '',
      current_amount: '0',
      deadline: '',
    });
    setFormError('');
    setIsModalOpen(true);
  };

  const openEditModal = (goal: SavingsGoal) => {
    setEditingGoal(goal);
    setFormData({
      goal_name: goal.goal_name,
      target_amount: goal.target_amount.toString(),
      current_amount: goal.current_amount.toString(),
      deadline: goal.deadline || '',
    });
    setFormError('');
    setIsModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    const targetAmt = parseFloat(formData.target_amount);
    const currAmt = parseFloat(formData.current_amount) || 0;

    if (!formData.goal_name.trim()) {
      setFormError('Goal title is required.');
      return;
    }
    if (isNaN(targetAmt) || targetAmt <= 0) {
      setFormError('Please enter a positive target amount.');
      return;
    }

    try {
      setIsSubmitting(true);
      if (editingGoal) {
        await api.updateSavingsGoal(editingGoal.id, {
          goal_name: formData.goal_name.trim(),
          target_amount: targetAmt,
          current_amount: currAmt,
          deadline: formData.deadline || '',
        });
      } else {
        await api.addSavingsGoal({
          goal_name: formData.goal_name.trim(),
          target_amount: targetAmt,
          current_amount: currAmt,
          deadline: formData.deadline || '',
        });
      }
      setIsModalOpen(false);
      fetchGoals();
      if (onRefreshOverview) onRefreshOverview();
    } catch (err: any) {
      setFormError(err.message || 'Failed to save savings goal.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleQuickContribute = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!contributeModal.goal) return;
    const addAmt = parseFloat(contributeModal.amount);
    if (isNaN(addAmt) || addAmt <= 0) return;

    try {
      await api.updateSavingsGoal(contributeModal.goal.id, {
        add_contribution: addAmt,
      });
      setContributeModal({ isOpen: false, goal: null, amount: '' });
      fetchGoals();
    } catch (err: any) {
      alert(err.message || 'Failed to add contribution.');
    }
  };

  const handleDelete = async (id: string, name: string) => {
    if (!window.confirm(`Delete savings goal "${name}"?`)) return;
    try {
      await api.deleteSavingsGoal(id);
      fetchGoals();
    } catch (err: any) {
      alert(err.message || 'Failed to delete goal.');
    }
  };

  const totalTarget = goals.reduce((sum, g) => sum + g.target_amount, 0);
  const totalSaved = goals.reduce((sum, g) => sum + g.current_amount, 0);
  const overallProgressPct = totalTarget > 0 ? Math.round((totalSaved / totalTarget) * 100) : 0;

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-2">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 flex items-center gap-2">
            Savings Goals
          </h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Plan milestones, track emergency reserves, and log contributions over time.
          </p>
        </div>

        <button
          onClick={openAddModal}
          className="flex items-center space-x-1.5 px-4 py-2 rounded-lg text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-white shadow-xs transition-colors self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>New Savings Goal</span>
        </button>
      </div>

      {/* Summary KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {/* Net Savings from current cashflow */}
        <div className="bg-white border border-slate-200/80 rounded-xl p-5 shadow-xs">
          <span className="text-xs font-medium text-slate-500">Monthly Net Savings</span>
          <div className={`text-2xl font-bold mt-1 ${netSavings >= 0 ? 'text-slate-900' : 'text-rose-600'}`}>
            {currency}{netSavings.toLocaleString()}
          </div>
          <span className="text-xs text-slate-500 mt-1 inline-block">Surplus available to deposit</span>
        </div>

        {/* Total Goal Reserves */}
        <div className="bg-white border border-slate-200/80 rounded-xl p-5 shadow-xs">
          <span className="text-xs font-medium text-slate-500">Total Saved Across Goals</span>
          <div className="text-2xl font-bold text-slate-900 mt-1">
            {currency}{totalSaved.toLocaleString()}
          </div>
          <span className="text-xs text-slate-500 mt-1 inline-block">
            Target: {currency}{totalTarget.toLocaleString()}
          </span>
        </div>

        {/* Aggregate Goal Progress */}
        <div className="bg-white border border-slate-200/80 rounded-xl p-5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500">Overall Progress</span>
            <span className="text-xs font-semibold text-slate-900">{overallProgressPct}%</span>
          </div>
          <div className="h-2 bg-slate-100 rounded-full overflow-hidden my-2">
            <div
              className="h-full bg-emerald-500 rounded-full transition-all duration-500"
              style={{ width: `${Math.min(100, overallProgressPct)}%` }}
            ></div>
          </div>
          <div className="flex justify-between text-xs text-slate-500">
            <span>{goals.length} active goals</span>
            <span>{currency}{Math.max(0, totalTarget - totalSaved).toLocaleString()} left</span>
          </div>
        </div>
      </div>

      {/* Goals Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {loading ? (
          <div className="col-span-full py-12 text-center text-slate-400">
            Loading savings goals...
          </div>
        ) : goals.length === 0 ? (
          <div className="col-span-full bg-white border border-slate-200/80 rounded-xl p-8 text-center space-y-3 shadow-xs">
            <div className="w-10 h-10 rounded-full bg-slate-100 text-slate-600 flex items-center justify-center mx-auto">
              <PiggyBank className="w-5 h-5" />
            </div>
            <h3 className="text-sm font-semibold text-slate-900">No Savings Goals Set Yet</h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto">
              Track emergency funds, vacation funds, or gadget purchases with concrete milestones.
            </p>
            <button
              onClick={openAddModal}
              className="px-4 py-2 rounded-lg text-xs font-medium bg-slate-900 hover:bg-slate-800 text-white transition-colors inline-flex items-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Create Your First Goal</span>
            </button>
          </div>
        ) : (
          goals.map((g) => {
            const progressPct = g.target_amount > 0 ? Math.round((g.current_amount / g.target_amount) * 100) : 0;
            const remaining = Math.max(0, g.target_amount - g.current_amount);
            const isFinished = progressPct >= 100;
            return (
              <div
                key={g.id}
                className="bg-white border border-slate-200/80 rounded-xl p-5 shadow-xs flex flex-col justify-between hover:border-slate-300 transition-colors"
              >
                <div>
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="font-semibold text-slate-900 text-sm">
                        {g.goal_name}
                      </h3>
                      {g.deadline && (
                        <div className="flex items-center space-x-1 text-[11px] text-slate-500 mt-0.5">
                          <Calendar className="w-3 h-3 text-slate-400" />
                          <span>Target: {g.deadline}</span>
                        </div>
                      )}
                    </div>
                    <div className="flex items-center space-x-1">
                      <button
                        onClick={() => openEditModal(g)}
                        className="p-1 rounded-md text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
                        title="Edit goal"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDelete(g.id, g.goal_name)}
                        className="p-1 rounded-md text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                        title="Delete goal"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Amounts */}
                  <div className="mt-4 flex items-baseline justify-between">
                    <div>
                      <span className="text-[11px] text-slate-500 font-medium block">Saved</span>
                      <span className="text-xl font-bold text-slate-900">
                        {currency}{g.current_amount.toLocaleString()}
                      </span>
                    </div>
                    <div className="text-right">
                      <span className="text-[11px] text-slate-500 font-medium block">Target</span>
                      <span className="text-sm font-semibold text-slate-600">
                        {currency}{g.target_amount.toLocaleString()}
                      </span>
                    </div>
                  </div>

                  {/* Progress Bar */}
                  <div className="mt-3 space-y-1.5">
                    <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-500 ${
                          isFinished ? 'bg-emerald-500' : 'bg-emerald-600'
                        }`}
                        style={{ width: `${Math.min(100, progressPct)}%` }}
                      ></div>
                    </div>
                    <div className="flex justify-between text-[11px] text-slate-500">
                      <span className="font-medium text-slate-700">{progressPct}% complete</span>
                      <span>
                        {isFinished
                          ? 'Goal Reached!'
                          : `${currency}${remaining.toLocaleString()} left`}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Contribution Action */}
                <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                  <button
                    onClick={() =>
                      setContributeModal({
                        isOpen: true,
                        goal: g,
                        amount: '1000',
                      })
                    }
                    className="flex-1 flex items-center justify-center space-x-1.5 py-1.5 px-3 rounded-lg text-xs font-medium bg-slate-100 hover:bg-slate-200 text-slate-800 transition-colors"
                  >
                    <PlusCircle className="w-3.5 h-3.5 text-slate-600" />
                    <span>Deposit Funds</span>
                  </button>

                  <button
                    onClick={() =>
                      api
                        .updateSavingsGoal(g.id, { add_contribution: 500 })
                        .then(() => fetchGoals())
                    }
                    className="py-1.5 px-2.5 rounded-lg text-xs font-medium bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 transition-colors"
                    title="Quick deposit 500"
                  >
                    +{currency}500
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Add / Edit Goal Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs">
          <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-md p-6 shadow-xl relative">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-base font-semibold text-slate-900 flex items-center gap-2">
                <Target className="w-5 h-5 text-slate-700" />
                {editingGoal ? 'Edit Savings Goal' : 'Create Savings Goal'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {formError && (
              <div className="mt-3 p-2.5 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 text-xs">
                {formError}
              </div>
            )}

            <form onSubmit={handleSubmit} className="mt-4 space-y-4 text-xs">
              <div>
                <label className="block font-medium text-slate-700 mb-1">
                  Goal Title <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  placeholder="e.g. Emergency Reserve, Laptop Fund"
                  value={formData.goal_name}
                  onChange={(e) => setFormData({ ...formData, goal_name: e.target.value })}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-slate-900 placeholder-slate-400 focus:outline-none focus:border-slate-900"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">
                    Target Amount ({currency}) <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="number"
                    step="any"
                    placeholder="e.g. 50000"
                    value={formData.target_amount}
                    onChange={(e) => setFormData({ ...formData, target_amount: e.target.value })}
                    className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-slate-900 placeholder-slate-400 focus:outline-none focus:border-slate-900 font-medium"
                    required
                  />
                </div>

                <div>
                  <label className="block font-medium text-slate-700 mb-1">Current Saved ({currency})</label>
                  <input
                    type="number"
                    step="any"
                    placeholder="e.g. 5000"
                    value={formData.current_amount}
                    onChange={(e) => setFormData({ ...formData, current_amount: e.target.value })}
                    className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-slate-900 placeholder-slate-400 focus:outline-none focus:border-slate-900 font-medium"
                  />
                </div>
              </div>

              <div>
                <label className="block font-medium text-slate-700 mb-1">Target Date (Optional)</label>
                <input
                  type="date"
                  value={formData.deadline}
                  onChange={(e) => setFormData({ ...formData, deadline: e.target.value })}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:border-slate-900"
                />
              </div>

              <div className="pt-2 flex items-center justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-lg bg-white border border-slate-200 text-slate-700 hover:bg-slate-50 text-xs font-medium transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-4 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 text-white text-xs font-medium transition-colors disabled:opacity-50"
                >
                  {isSubmitting ? 'Saving...' : editingGoal ? 'Save Changes' : 'Create Goal'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Contribute Modal */}
      {contributeModal.isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-xs">
          <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-sm p-6 shadow-xl relative">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-sm font-semibold text-slate-900 flex items-center gap-2">
                <PlusCircle className="w-4 h-4 text-emerald-600" />
                Deposit to {contributeModal.goal?.goal_name}
              </h3>
              <button
                onClick={() => setContributeModal({ isOpen: false, goal: null, amount: '' })}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleQuickContribute} className="mt-4 space-y-4 text-xs">
              <div>
                <label className="block font-medium text-slate-700 mb-1">
                  Deposit Amount ({currency})
                </label>
                <input
                  type="number"
                  step="any"
                  placeholder="e.g. 2000"
                  value={contributeModal.amount}
                  onChange={(e) =>
                    setContributeModal({ ...contributeModal, amount: e.target.value })
                  }
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-slate-900 text-sm font-medium focus:outline-none focus:border-slate-900"
                  required
                />
              </div>

              <div className="flex items-center space-x-2">
                {[500, 1000, 2500, 5000].map((preset) => (
                  <button
                    key={preset}
                    type="button"
                    onClick={() =>
                      setContributeModal({ ...contributeModal, amount: preset.toString() })
                    }
                    className="flex-1 py-1.5 rounded-lg bg-slate-50 hover:bg-slate-100 text-slate-700 text-xs font-medium border border-slate-200 transition-colors"
                  >
                    +{preset}
                  </button>
                ))}
              </div>

              <div className="pt-2 flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setContributeModal({ isOpen: false, goal: null, amount: '' })}
                  className="px-3.5 py-2 rounded-lg bg-white border border-slate-200 text-slate-700 text-xs font-medium hover:bg-slate-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-medium text-xs transition-colors"
                >
                  Confirm Deposit
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
