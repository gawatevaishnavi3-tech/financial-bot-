import React from 'react';
import {
  TrendingUp,
  TrendingDown,
  PiggyBank,
  PieChart,
  Plus,
  Bot,
  ChevronRight,
  ArrowUpRight,
  ArrowDownRight,
  AlertCircle,
  CheckCircle2,
  Sparkles,
} from 'lucide-react';
import { ActiveTab } from './Navbar';

interface DashboardViewProps {
  overview: any;
  currency: string;
  onNavigate: (tab: ActiveTab) => void;
  onRefresh: () => void;
  isLoading: boolean;
}

const CATEGORY_COLORS: Record<string, string> = {
  Food: '#f97316',
  Rent: '#3b82f6',
  Transport: '#0ea5e9',
  Education: '#8b5cf6',
  Healthcare: '#ec4899',
  Shopping: '#f43f5e',
  Entertainment: '#eab308',
  Utilities: '#14b8a6',
  Bills: '#64748b',
  Other: '#94a3b8',
};

export const DashboardView: React.FC<DashboardViewProps> = ({
  overview,
  currency,
  onNavigate,
  onRefresh,
  isLoading,
}) => {
  if (!overview && isLoading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[360px] text-slate-500">
        <div className="w-8 h-8 border-3 border-emerald-600/20 border-t-emerald-600 rounded-full animate-spin mb-3"></div>
        <p className="text-sm font-medium">Loading financial summary...</p>
      </div>
    );
  }

  const {
    totalIncome = 0,
    totalExpenses = 0,
    netSavings = 0,
    overallBudget = 0,
    remainingBudget = 0,
    budgetUtilizationPct = 0,
    todayExpense = 0,
    weeklyExpense = 0,
    highestExpenseCategory = { category: 'None', amount: 0 },
    expensesByCategory = {},
    monthlyTrend = [],
  } = overview || {};

  const savingsRate = totalIncome > 0 ? Math.round((netSavings / totalIncome) * 100) : 0;

  // Category entries sorted descending
  const categoryEntries = Object.entries(expensesByCategory as Record<string, number>).sort(
    (a, b) => b[1] - a[1]
  );
  const totalCatExpenses = categoryEntries.reduce((sum, [, amt]) => sum + amt, 0);

  // SVG Donut calculation
  let cumulativeAngle = 0;
  const donutSegments = categoryEntries.map(([cat, amt]) => {
    const fraction = totalCatExpenses > 0 ? amt / totalCatExpenses : 0;
    const startAngle = cumulativeAngle;
    const endAngle = cumulativeAngle + fraction * 360;
    cumulativeAngle = endAngle;

    const radius = 40;
    const cx = 50;
    const cy = 50;
    const x1 = cx + radius * Math.cos((Math.PI * (startAngle - 90)) / 180);
    const y1 = cy + radius * Math.sin((Math.PI * (startAngle - 90)) / 180);
    const x2 = cx + radius * Math.cos((Math.PI * (endAngle - 90)) / 180);
    const y2 = cy + radius * Math.sin((Math.PI * (endAngle - 90)) / 180);
    const largeArc = fraction > 0.5 ? 1 : 0;

    const pathData =
      fraction >= 0.999
        ? `M ${cx}, ${cy - radius} A ${radius}, ${radius} 0 1, 0 ${cx - 0.01}, ${cy - radius}`
        : `M ${x1}, ${y1} A ${radius}, ${radius} 0 ${largeArc}, 1 ${x2}, ${y2}`;

    return {
      category: cat,
      amount: amt,
      fraction,
      color: CATEGORY_COLORS[cat] || '#94a3b8',
      pathData,
    };
  });

  return (
    <div className="space-y-6">
      {/* Top Header & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-2">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900">
            Overview
          </h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Your cash flow, spending breakdown, and financial status this month.
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={() => onNavigate('income')}
            className="flex items-center space-x-1.5 px-3.5 py-2 rounded-lg text-xs font-medium bg-white hover:bg-slate-50 text-slate-700 border border-slate-200/90 shadow-xs transition-colors"
          >
            <Plus className="w-3.5 h-3.5 text-slate-500" />
            <span>Add Income</span>
          </button>
          <button
            onClick={() => onNavigate('expenses')}
            className="flex items-center space-x-1.5 px-3.5 py-2 rounded-lg text-xs font-medium bg-slate-900 hover:bg-slate-800 text-white shadow-xs transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Expense</span>
          </button>
          <button
            onClick={() => onNavigate('advisor')}
            className="flex items-center space-x-1.5 px-3.5 py-2 rounded-lg text-xs font-medium bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200/80 transition-colors"
          >
            <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
            <span>Ask Advisor</span>
          </button>
        </div>
      </div>

      {/* 4 Clean Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Monthly Income */}
        <div className="bg-white border border-slate-200/80 rounded-xl p-5 shadow-xs hover:border-slate-300 transition-colors">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500">Monthly Income</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold text-slate-900 tracking-tight">
              {currency}{totalIncome.toLocaleString()}
            </div>
            <div className="flex items-center mt-1 text-xs text-slate-500 font-medium">
              <ArrowUpRight className="w-3.5 h-3.5 mr-0.5 text-emerald-600" />
              <span>Credited this month</span>
            </div>
          </div>
        </div>

        {/* Card 2: Total Expenses */}
        <div className="bg-white border border-slate-200/80 rounded-xl p-5 shadow-xs hover:border-slate-300 transition-colors">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500">Total Expenses</span>
            <div className="w-8 h-8 rounded-lg bg-rose-50 text-rose-700 flex items-center justify-center">
              <TrendingDown className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold text-slate-900 tracking-tight">
              {currency}{totalExpenses.toLocaleString()}
            </div>
            <div className="flex items-center gap-2 mt-1 text-xs text-slate-500">
              <span>Today: <strong className="text-slate-700 font-semibold">{currency}{todayExpense.toLocaleString()}</strong></span>
              <span>•</span>
              <span>7-day: <strong className="text-slate-700 font-semibold">{currency}{weeklyExpense.toLocaleString()}</strong></span>
            </div>
          </div>
        </div>

        {/* Card 3: Net Savings */}
        <div className="bg-white border border-slate-200/80 rounded-xl p-5 shadow-xs hover:border-slate-300 transition-colors">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500">Net Savings</span>
            <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-700 flex items-center justify-center">
              <PiggyBank className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className={`text-2xl font-bold tracking-tight ${netSavings >= 0 ? 'text-slate-900' : 'text-rose-600'}`}>
              {currency}{netSavings.toLocaleString()}
            </div>
            <div className="flex items-center mt-1 text-xs text-slate-500">
              <span>Savings Rate: </span>
              <span className={`ml-1 font-semibold ${savingsRate >= 20 ? 'text-emerald-700' : savingsRate > 0 ? 'text-amber-700' : 'text-rose-700'}`}>
                {savingsRate}%
              </span>
              <span className="ml-1 text-slate-400">of income</span>
            </div>
          </div>
        </div>

        {/* Card 4: Monthly Budget Status */}
        <div className="bg-white border border-slate-200/80 rounded-xl p-5 shadow-xs hover:border-slate-300 transition-colors">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500">Budget Status</span>
            <div className="w-8 h-8 rounded-lg bg-purple-50 text-purple-700 flex items-center justify-center">
              <PieChart className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold text-slate-900 tracking-tight">
              {currency}{Math.abs(remainingBudget).toLocaleString()}
              {remainingBudget < 0 && <span className="text-xs font-normal text-rose-600 ml-1">(Over)</span>}
            </div>
            <div className="flex items-center justify-between mt-1 text-xs">
              <span className={`font-medium ${budgetUtilizationPct > 100 ? 'text-rose-600' : budgetUtilizationPct >= 80 ? 'text-amber-600' : 'text-emerald-700'}`}>
                {budgetUtilizationPct > 100 ? 'Over budget' : budgetUtilizationPct >= 80 ? 'Near limit' : 'Within budget'}
              </span>
              <span className="text-slate-400">{budgetUtilizationPct}% used</span>
            </div>
          </div>
        </div>
      </div>

      {/* Human AI Financial Insight Banner */}
      <div className="bg-emerald-50/60 border border-emerald-200/90 rounded-xl p-4 sm:p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-start space-x-3.5">
          <div className="w-9 h-9 rounded-lg bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-xs">
            <Bot className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-semibold text-slate-900">Monthly Advisor Insight</h3>
              <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 border border-emerald-200">
                Gemini AI
              </span>
            </div>
            <p className="text-xs text-slate-600 mt-1 max-w-2xl leading-relaxed">
              {budgetUtilizationPct > 100 ? (
                <span className="text-rose-700 font-medium">
                  You have exceeded your planned monthly limit by {currency}
                  {(totalExpenses - overallBudget).toLocaleString()}. Consider reducing expenses in {highestExpenseCategory.category} to get back on track.
                </span>
              ) : (
                <span>
                  You are saving <strong>{savingsRate}%</strong> of your income this month. Your largest expense category is{' '}
                  <strong>{highestExpenseCategory.category}</strong> ({currency}
                  {highestExpenseCategory.amount.toLocaleString()}).
                </span>
              )}
            </p>
          </div>
        </div>

        <button
          onClick={() => onNavigate('advisor')}
          className="flex items-center space-x-1.5 px-4 py-2 rounded-lg text-xs font-semibold bg-emerald-700 hover:bg-emerald-800 text-white shadow-xs transition-colors shrink-0"
        >
          <span>View Full Advice</span>
          <ChevronRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Main Charts & Visualizations */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Chart 1: Expenses by Category */}
        <div className="bg-white border border-slate-200/80 rounded-xl p-5 flex flex-col shadow-xs">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h3 className="text-sm font-semibold text-slate-900">Expenses by Category</h3>
              <p className="text-xs text-slate-500">Spending breakdown for this month</p>
            </div>
            <button
              onClick={() => onNavigate('expenses')}
              className="text-xs text-slate-600 hover:text-slate-900 font-medium flex items-center"
            >
              Details <ChevronRight className="w-3 h-3 ml-0.5" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 items-center gap-4 my-4 flex-1">
            {/* Donut */}
            <div className="flex items-center justify-center relative">
              <svg viewBox="0 0 100 100" className="w-36 h-36 transform -rotate-90">
                {donutSegments.length === 0 ? (
                  <circle cx="50" cy="50" r="40" fill="transparent" stroke="#f1f5f9" strokeWidth="12" />
                ) : (
                  donutSegments.map((seg, i) => (
                    <path
                      key={i}
                      d={seg.pathData}
                      fill="transparent"
                      stroke={seg.color}
                      strokeWidth="12"
                      strokeLinecap="round"
                      className="transition-all duration-300 hover:opacity-80"
                    />
                  ))
                )}
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center text-center pointer-events-none">
                <span className="text-[10px] text-slate-400 font-medium">Total Spent</span>
                <span className="text-sm font-bold text-slate-900">{currency}{totalExpenses.toLocaleString()}</span>
              </div>
            </div>

            {/* Category List */}
            <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
              {categoryEntries.length === 0 ? (
                <p className="text-xs text-slate-400 text-center py-4">No expenses recorded yet.</p>
              ) : (
                categoryEntries.slice(0, 5).map(([cat, amt]) => {
                  const pct = totalCatExpenses > 0 ? Math.round((amt / totalCatExpenses) * 100) : 0;
                  const color = CATEGORY_COLORS[cat] || '#94a3b8';
                  return (
                    <div key={cat} className="flex items-center justify-between text-xs">
                      <div className="flex items-center space-x-2">
                        <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: color }}></span>
                        <span className="text-slate-700 font-medium truncate max-w-[110px]">{cat}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <span className="text-slate-400">{pct}%</span>
                        <span className="text-slate-900 font-semibold">{currency}{amt.toLocaleString()}</span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>

        {/* Chart 2: Monthly Cashflow Trend */}
        <div className="bg-white border border-slate-200/80 rounded-xl p-5 flex flex-col shadow-xs">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h3 className="text-sm font-semibold text-slate-900">Cash Flow Trend</h3>
              <p className="text-xs text-slate-500">Income vs. expenses over time</p>
            </div>
            <div className="flex items-center space-x-3 text-xs text-slate-600">
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-sm bg-emerald-500"></span> Income
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-sm bg-rose-400"></span> Expense
              </span>
            </div>
          </div>

          <div className="my-auto pt-4 pb-2 space-y-4">
            {monthlyTrend.map((item: any, idx: number) => {
              const maxVal = Math.max(...monthlyTrend.map((m: any) => Math.max(m.income, m.expenses)), 1000);
              const incWidth = Math.min(100, Math.round((item.income / maxVal) * 100));
              const expWidth = Math.min(100, Math.round((item.expenses / maxVal) * 100));

              return (
                <div key={idx} className="space-y-1.5">
                  <div className="flex justify-between text-xs text-slate-600">
                    <span className="font-medium text-slate-800">{item.month}</span>
                    <span className="font-mono text-slate-500">
                      +{currency}{(item.income / 1000).toFixed(0)}k / -{currency}{(item.expenses / 1000).toFixed(0)}k
                    </span>
                  </div>
                  <div className="space-y-1">
                    <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-emerald-500 rounded-full transition-all duration-500"
                        style={{ width: `${incWidth}%` }}
                      ></div>
                    </div>
                    <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-rose-400 rounded-full transition-all duration-500"
                        style={{ width: `${expWidth}%` }}
                      ></div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Chart 3: Budget Utilization */}
        <div className="bg-white border border-slate-200/80 rounded-xl p-5 flex flex-col shadow-xs">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h3 className="text-sm font-semibold text-slate-900">Budget Limits</h3>
              <p className="text-xs text-slate-500">Tracking monthly spending allowances</p>
            </div>
            <button
              onClick={() => onNavigate('budget')}
              className="text-xs text-slate-600 hover:text-slate-900 font-medium flex items-center"
            >
              Adjust <ChevronRight className="w-3 h-3 ml-0.5" />
            </button>
          </div>

          <div className="my-auto py-3 space-y-4">
            {/* Overall Gauge Bar */}
            <div className="bg-slate-50 p-3.5 rounded-lg border border-slate-200/80 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-slate-800">Overall Monthly Budget</span>
                <span className="font-mono text-slate-600">
                  {currency}{totalExpenses.toLocaleString()} / {currency}{overallBudget.toLocaleString()}
                </span>
              </div>
              <div className="h-2 bg-slate-200 rounded-full overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all duration-500 ${
                    budgetUtilizationPct > 100
                      ? 'bg-rose-500'
                      : budgetUtilizationPct >= 80
                      ? 'bg-amber-500'
                      : 'bg-emerald-500'
                  }`}
                  style={{ width: `${Math.min(100, budgetUtilizationPct)}%` }}
                ></div>
              </div>
              <div className="flex items-center justify-between text-[11px] text-slate-500">
                <span>{budgetUtilizationPct}% used</span>
                <span className={remainingBudget >= 0 ? 'text-emerald-700 font-medium' : 'text-rose-600 font-bold'}>
                  {remainingBudget >= 0 ? `${currency}${remainingBudget.toLocaleString()} remaining` : `${currency}${Math.abs(remainingBudget).toLocaleString()} over budget`}
                </span>
              </div>
            </div>

            {/* Key category limits */}
            <div className="space-y-2.5">
              <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                Top Categories
              </span>
              {categoryEntries.slice(0, 3).map(([cat, spent]) => {
                const limit = overview?.categoryBudgets?.[cat] || Math.round((overallBudget || spent * 1.2) * 0.25);
                const pct = limit > 0 ? Math.round((spent / limit) * 100) : 0;
                return (
                  <div key={cat} className="space-y-1">
                    <div className="flex justify-between text-xs">
                      <span className="text-slate-700 font-medium">{cat}</span>
                      <span className="font-mono text-slate-500">
                        {currency}{spent.toLocaleString()} / {currency}{limit.toLocaleString()}
                      </span>
                    </div>
                    <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full ${
                          pct > 100 ? 'bg-rose-500' : pct >= 80 ? 'bg-amber-500' : 'bg-emerald-500'
                        }`}
                        style={{ width: `${Math.min(100, pct)}%` }}
                      ></div>
                    </div>
                  </div>
                );
              })}
            </div>

            <button
              onClick={() => onNavigate('savings')}
              className="w-full flex items-center justify-center space-x-1 py-2 rounded-lg text-xs font-medium bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors"
            >
              <PiggyBank className="w-3.5 h-3.5 mr-1 text-slate-600" />
              <span>View Savings Goals</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
