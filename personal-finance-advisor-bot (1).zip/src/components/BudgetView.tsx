import React, { useState, useEffect } from 'react';
import {
  PieChart,
  Plus,
  Trash2,
  AlertTriangle,
  CheckCircle2,
  Target,
  Sparkles,
  ArrowRight,
} from 'lucide-react';
import { api } from '../api';
import { EXPENSE_CATEGORIES } from './ExpenseView';

interface BudgetViewProps {
  currency: string;
  onRefreshOverview: () => void;
  onNavigateToAdvisor: () => void;
}

export const BudgetView: React.FC<BudgetViewProps> = ({
  currency,
  onRefreshOverview,
  onNavigateToAdvisor,
}) => {
  const [budgets, setBudgets] = useState<any[]>([]);
  const [totalExpenses, setTotalExpenses] = useState<number>(0);
  const [loading, setLoading] = useState<boolean>(true);

  const now = new Date();
  const [month] = useState<number>(now.getMonth() + 1);
  const [year] = useState<number>(now.getFullYear());

  // Add / Set Budget form
  const [selectedCategory, setSelectedCategory] = useState<string>('Overall');
  const [budgetAmount, setBudgetAmount] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const fetchBudgets = async () => {
    try {
      setLoading(true);
      const res = await api.getBudgets(month, year);
      setBudgets(res.budgets);
      setTotalExpenses(res.totalExpenses);
    } catch (err: any) {
      console.error('Failed to fetch budgets:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBudgets();
  }, [month, year]);

  const handleSaveBudget = async (e: React.FormEvent) => {
    e.preventDefault();
    setMessage(null);
    const amt = parseFloat(budgetAmount);
    if (isNaN(amt) || amt < 0) {
      setMessage({ type: 'error', text: 'Please enter a valid non-negative amount.' });
      return;
    }

    try {
      setIsSubmitting(true);
      await api.setBudget(selectedCategory, amt, month, year);
      setBudgetAmount('');
      setMessage({ type: 'success', text: `Budget limit for ${selectedCategory} updated.` });
      fetchBudgets();
      onRefreshOverview();
    } catch (err: any) {
      setMessage({ type: 'error', text: err.message || 'Failed to set budget.' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteBudget = async (id: string, category: string) => {
    if (!window.confirm(`Remove budget threshold for ${category}?`)) return;
    try {
      await api.deleteBudget(id);
      fetchBudgets();
      onRefreshOverview();
    } catch (err: any) {
      alert(err.message || 'Failed to remove budget.');
    }
  };

  const overallBudget = budgets.find((b) => b.category.toLowerCase() === 'overall');
  const overallLimit = overallBudget ? overallBudget.amount : 0;
  const overallActual = totalExpenses;
  const overallRemaining = overallLimit - overallActual;
  const overallUtilizationPct = overallLimit > 0 ? Math.round((overallActual / overallLimit) * 100) : 0;

  const categoryBudgets = budgets.filter((b) => b.category.toLowerCase() !== 'overall');

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-2">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 flex items-center gap-2">
            Budgets
          </h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Set monthly spending limits per category to prevent overspending.
          </p>
        </div>

        <button
          onClick={onNavigateToAdvisor}
          className="flex items-center space-x-1.5 px-3.5 py-2 rounded-lg text-xs font-semibold bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200/80 transition-colors self-start sm:self-auto"
        >
          <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
          <span>Advisor Recommendations</span>
        </button>
      </div>

      {/* Main Overall Monthly Budget Card */}
      <div className="bg-white border border-slate-200/80 rounded-xl p-6 shadow-xs">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 items-center">
          <div className="lg:col-span-3 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center space-x-2.5">
                <div className="w-9 h-9 rounded-lg bg-slate-100 text-slate-700 flex items-center justify-center">
                  <Target className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-base font-semibold text-slate-900">Overall Monthly Budget</h2>
                  <p className="text-xs text-slate-500">Remaining Budget = Total Budget − Total Expenses</p>
                </div>
              </div>

              {/* Status Indicator */}
              <div
                className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium border ${
                  overallUtilizationPct > 100
                    ? 'bg-rose-50 border-rose-200 text-rose-700'
                    : overallUtilizationPct >= 80
                    ? 'bg-amber-50 border-amber-200 text-amber-700'
                    : 'bg-emerald-50 border-emerald-200 text-emerald-700'
                }`}
              >
                {overallUtilizationPct > 100 ? (
                  <>
                    <AlertTriangle className="w-3.5 h-3.5" />
                    <span>Over Budget</span>
                  </>
                ) : overallUtilizationPct >= 80 ? (
                  <>
                    <AlertTriangle className="w-3.5 h-3.5" />
                    <span>Near Limit</span>
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Within Budget</span>
                  </>
                )}
              </div>
            </div>

            {/* Gauge progress bar */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs font-medium text-slate-600">
                <span>Budget Utilization</span>
                <span>{overallUtilizationPct}%</span>
              </div>
              <div className="h-2.5 bg-slate-100 rounded-full overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all duration-500 ${
                    overallUtilizationPct > 100
                      ? 'bg-rose-500'
                      : overallUtilizationPct >= 80
                      ? 'bg-amber-500'
                      : 'bg-emerald-500'
                  }`}
                  style={{ width: `${Math.min(100, overallUtilizationPct)}%` }}
                ></div>
              </div>
            </div>

            {/* Numbers breakdown */}
            <div className="grid grid-cols-3 gap-3 pt-1 text-xs">
              <div className="bg-slate-50 p-3 rounded-lg border border-slate-100">
                <span className="text-slate-500">Monthly Budget</span>
                <div className="text-lg font-bold text-slate-900 mt-0.5">
                  {currency}{overallLimit.toLocaleString()}
                </div>
              </div>
              <div className="bg-slate-50 p-3 rounded-lg border border-slate-100">
                <span className="text-slate-500">Actual Spent</span>
                <div className="text-lg font-bold text-slate-900 mt-0.5">
                  {currency}{overallActual.toLocaleString()}
                </div>
              </div>
              <div className="bg-slate-50 p-3 rounded-lg border border-slate-100">
                <span className="text-slate-500">Remaining</span>
                <div
                  className={`text-lg font-bold mt-0.5 ${
                    overallRemaining >= 0 ? 'text-emerald-700' : 'text-rose-600'
                  }`}
                >
                  {currency}{Math.abs(overallRemaining).toLocaleString()}
                  {overallRemaining < 0 && <span className="text-xs font-normal ml-1">(Over)</span>}
                </div>
              </div>
            </div>
          </div>

          {/* Quick set Overall Budget */}
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200/80 space-y-3">
            <span className="text-xs font-semibold text-slate-800 block">
              Set Overall Limit
            </span>
            <div className="space-y-2">
              <input
                type="number"
                placeholder="e.g. 30000"
                value={selectedCategory === 'Overall' ? budgetAmount : ''}
                onChange={(e) => {
                  setSelectedCategory('Overall');
                  setBudgetAmount(e.target.value);
                }}
                className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-slate-900 text-xs font-medium focus:outline-none focus:border-slate-900"
              />
              <button
                onClick={(e) => {
                  setSelectedCategory('Overall');
                  handleSaveBudget(e);
                }}
                disabled={isSubmitting || !budgetAmount}
                className="w-full py-2 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-medium text-xs transition-colors disabled:opacity-50"
              >
                Save Overall Limit
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Set Category-wise Limits Form & List */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Set Form */}
        <div className="bg-white border border-slate-200/80 rounded-xl p-5 shadow-xs h-fit">
          <h3 className="text-sm font-semibold text-slate-900 flex items-center gap-2 pb-3 border-b border-slate-100">
            <Plus className="w-4 h-4 text-slate-600" />
            Set Category Limit
          </h3>

          {message && (
            <div
              className={`mt-3 p-2.5 rounded-lg text-xs border ${
                message.type === 'success'
                  ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                  : 'bg-rose-50 border-rose-200 text-rose-800'
              }`}
            >
              {message.text}
            </div>
          )}

          <form onSubmit={handleSaveBudget} className="mt-4 space-y-3 text-xs">
            <div>
              <label className="block font-medium text-slate-700 mb-1">Expense Category</label>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-slate-900 text-xs focus:outline-none focus:border-slate-900"
              >
                <option value="Overall">Overall (Total Cap)</option>
                {EXPENSE_CATEGORIES.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-medium text-slate-700 mb-1">
                Monthly Cap ({currency})
              </label>
              <input
                type="number"
                step="any"
                placeholder="e.g. 5000"
                value={budgetAmount}
                onChange={(e) => setBudgetAmount(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-slate-900 text-xs font-medium focus:outline-none focus:border-slate-900"
                required
              />
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-2.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-medium text-xs transition-colors disabled:opacity-50 mt-2"
            >
              {isSubmitting ? 'Saving...' : `Save Limit for ${selectedCategory}`}
            </button>
          </form>
        </div>

        {/* Category Budget Comparisons List */}
        <div className="lg:col-span-2 bg-white border border-slate-200/80 rounded-xl p-5 shadow-xs">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h3 className="text-sm font-semibold text-slate-900">Category Budgets</h3>
              <p className="text-xs text-slate-500">Actual spend vs. configured category limit</p>
            </div>
            <span className="text-xs text-slate-500">
              Month {month}/{year}
            </span>
          </div>

          <div className="mt-4 space-y-3">
            {loading ? (
              <p className="text-xs text-slate-400 py-6 text-center">Loading budget metrics...</p>
            ) : categoryBudgets.length === 0 ? (
              <div className="py-8 text-center text-slate-500 space-y-1">
                <p className="text-xs font-medium">No category limits configured yet.</p>
                <p className="text-xs text-slate-400">
                  Select a category from the form on the left to set custom monthly spending limits.
                </p>
              </div>
            ) : (
              categoryBudgets.map((b) => {
                const isOver = b.status === 'over';
                const isWarning = b.status === 'warning';

                return (
                  <div
                    key={b.id}
                    className="p-3.5 rounded-xl bg-slate-50/70 border border-slate-200/80 hover:bg-slate-50 transition-colors space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <span className="font-semibold text-slate-900 text-xs">{b.category}</span>
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-medium border ${
                            isOver
                              ? 'bg-rose-50 border-rose-200 text-rose-700'
                              : isWarning
                              ? 'bg-amber-50 border-amber-200 text-amber-700'
                              : 'bg-emerald-50 border-emerald-200 text-emerald-700'
                          }`}
                        >
                          {isOver ? 'Over budget' : isWarning ? 'Near limit' : 'On track'}
                        </span>
                      </div>

                      <div className="flex items-center space-x-3 text-xs">
                        <span className="font-medium text-slate-900">
                          {currency}{b.spent.toLocaleString()}{' '}
                          <span className="text-slate-400 font-normal">/ {currency}{b.amount.toLocaleString()}</span>
                        </span>
                        <button
                          onClick={() => handleDeleteBudget(b.id, b.category)}
                          className="p-1 text-slate-400 hover:text-rose-600 rounded transition-colors"
                          title="Remove category budget"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    <div className="h-1.5 bg-slate-200 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-300 ${
                          isOver ? 'bg-rose-500' : isWarning ? 'bg-amber-500' : 'bg-emerald-500'
                        }`}
                        style={{ width: `${Math.min(100, b.percentage)}%` }}
                      ></div>
                    </div>

                    <div className="flex justify-between text-[11px] text-slate-500">
                      <span>{b.percentage}% utilized</span>
                      <span className={b.remaining >= 0 ? 'text-slate-600' : 'text-rose-600 font-semibold'}>
                        {b.remaining >= 0
                          ? `${currency}${b.remaining.toLocaleString()} left`
                          : `${currency}${Math.abs(b.remaining).toLocaleString()} over limit`}
                      </span>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
