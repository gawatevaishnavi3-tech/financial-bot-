import React, { useState, useEffect, useRef } from 'react';
import {
  Bot,
  Sparkles,
  Send,
  RefreshCw,
  AlertTriangle,
  CheckCircle2,
  TrendingDown,
  ShieldCheck,
  Target,
  Lightbulb,
  MessageSquare,
  FileSpreadsheet,
  Trash2,
} from 'lucide-react';
import { AIAnalysisResult, ChatMessage } from '../types';
import { api } from '../api';

interface AdvisorViewProps {
  currency: string;
  onRefreshOverview: () => void;
}

export const AdvisorView: React.FC<AdvisorViewProps> = ({ currency, onRefreshOverview }) => {
  const [activeSubTab, setActiveSubTab] = useState<'audit' | 'chat'>('audit');

  // AI Audit State
  const [analysis, setAnalysis] = useState<AIAnalysisResult | null>(null);
  const [loadingAnalysis, setLoadingAnalysis] = useState<boolean>(false);
  const [analysisError, setAnalysisError] = useState<string>('');

  // Chat State
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputMessage, setInputMessage] = useState<string>('');
  const [loadingChat, setLoadingChat] = useState<boolean>(false);
  const chatBottomRef = useRef<HTMLDivElement>(null);

  const fetchAnalysis = async () => {
    try {
      setLoadingAnalysis(true);
      setAnalysisError('');
      const res = await api.getAIAnalysis();
      setAnalysis(res.analysis);
    } catch (err: any) {
      setAnalysisError(err.message || 'Failed to retrieve AI analysis.');
    } finally {
      setLoadingAnalysis(false);
    }
  };

  const fetchChatHistory = async () => {
    try {
      const res = await api.getAIChatHistory();
      setMessages(res.history);
    } catch (err: any) {
      console.error('Error fetching chat history:', err);
    }
  };

  useEffect(() => {
    fetchAnalysis();
    fetchChatHistory();
  }, []);

  useEffect(() => {
    if (activeSubTab === 'chat') {
      chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, activeSubTab]);

  const handleSendMessage = async (textToSend?: string) => {
    const text = textToSend || inputMessage;
    if (!text.trim() || loadingChat) return;

    setInputMessage('');
    const tempUserMsg: ChatMessage = {
      id: 'temp-' + Date.now(),
      role: 'user',
      content: text.trim(),
      timestamp: new Date().toISOString(),
    };
    setMessages((prev) => [...prev, tempUserMsg]);
    setLoadingChat(true);

    try {
      const res = await api.sendAIChatMessage(text.trim());
      setMessages((prev) => [
        ...prev.filter((m) => m.id !== tempUserMsg.id),
        res.userMessage,
        res.botMessage,
      ]);
    } catch (err: any) {
      const errorBotMsg: ChatMessage = {
        id: 'err-' + Date.now(),
        role: 'assistant',
        content: `Error contacting advisor: ${err.message}. Please check connection.`,
        timestamp: new Date().toISOString(),
      };
      setMessages((prev) => [...prev, errorBotMsg]);
    } finally {
      setLoadingChat(false);
    }
  };

  const handleClearChat = async () => {
    if (!window.confirm('Clear conversation history with your advisor?')) return;
    try {
      await api.clearAIChatHistory();
      setMessages([]);
    } catch (err: any) {
      alert(err.message || 'Failed to clear chat.');
    }
  };

  const PROMPT_SUGGESTIONS = [
    'How can I boost my monthly savings rate to 30%?',
    'Which specific expense category is taking up the most money?',
    'Can I afford a larger discretionary purchase next month?',
    'Build me a 3-month emergency fund road map.',
  ];

  return (
    <div className="space-y-6">
      {/* Top Header & Sub-Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-2">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 flex items-center gap-2">
            AI Financial Advisor
          </h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Personalized financial audits and interactive guidance powered by Gemini.
          </p>
        </div>

        <div className="flex items-center p-1 bg-white border border-slate-200 rounded-lg shadow-xs">
          <button
            onClick={() => setActiveSubTab('audit')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
              activeSubTab === 'audit'
                ? 'bg-slate-900 text-white'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            <span>Financial Audit</span>
          </button>
          <button
            onClick={() => setActiveSubTab('chat')}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
              activeSubTab === 'chat'
                ? 'bg-slate-900 text-white'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>Interactive Chat</span>
          </button>
        </div>
      </div>

      {/* Sub-Tab 1: Structured AI Financial Audit */}
      {activeSubTab === 'audit' && (
        <div className="space-y-6">
          {/* Action Bar */}
          <div className="flex items-center justify-between bg-white border border-slate-200/80 rounded-xl p-4 shadow-xs">
            <div className="flex items-center space-x-2">
              <Sparkles className="w-4 h-4 text-emerald-600" />
              <span className="text-xs text-slate-600 font-medium">
                Analysis generated from your real income, expenses, and budget limits.
              </span>
            </div>

            <button
              onClick={fetchAnalysis}
              disabled={loadingAnalysis}
              className="flex items-center space-x-1.5 px-3.5 py-1.5 rounded-lg text-xs font-medium bg-slate-900 hover:bg-slate-800 text-white transition-colors disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loadingAnalysis ? 'animate-spin' : ''}`} />
              <span>{loadingAnalysis ? 'Analyzing...' : 'Refresh Audit'}</span>
            </button>
          </div>

          {analysisError && (
            <div className="p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">
              {analysisError}
            </div>
          )}

          {loadingAnalysis ? (
            <div className="bg-white border border-slate-200/80 rounded-xl p-12 text-center space-y-4 shadow-xs">
              <div className="w-10 h-10 border-3 border-emerald-600/20 border-t-emerald-600 rounded-full animate-spin mx-auto"></div>
              <div>
                <h3 className="text-sm font-semibold text-slate-900">Evaluating Your Financial Picture...</h3>
                <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1">
                  Analyzing cash flow trends, budget variances, and cost-saving opportunities.
                </p>
              </div>
            </div>
          ) : analysis ? (
            <div className="space-y-6">
              {/* Financial Health Score & Spending Summary Banner */}
              <div className="bg-white border border-slate-200/80 rounded-xl p-6 shadow-xs">
                <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 items-center">
                  {/* Health Score */}
                  <div className="flex flex-col items-center justify-center p-4 bg-slate-50 rounded-xl border border-slate-100 text-center">
                    <span className="text-xs font-medium text-slate-500">
                      Health Score
                    </span>
                    <div className="mt-1">
                      <div className="text-4xl font-bold text-slate-900 tracking-tight">
                        {analysis.financial_health_score}
                        <span className="text-sm font-normal text-slate-400">/100</span>
                      </div>
                    </div>
                    <span className="mt-2 text-xs font-semibold px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200">
                      Grade: {analysis.financial_health_grade}
                    </span>
                  </div>

                  {/* Executive Spending Assessment */}
                  <div className="lg:col-span-3 space-y-2">
                    <h3 className="text-base font-semibold text-slate-900 flex items-center gap-2">
                      <ShieldCheck className="w-5 h-5 text-emerald-600" />
                      Executive Cash Flow Evaluation
                    </h3>
                    <p className="text-xs text-slate-600 leading-relaxed bg-slate-50/80 p-4 rounded-xl border border-slate-100">
                      {analysis.spending_summary}
                    </p>
                  </div>
                </div>
              </div>

              {/* Overspending Alerts Section */}
              <div className="bg-white border border-slate-200/80 rounded-xl p-5 space-y-4 shadow-xs">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <div className="flex items-center space-x-2">
                    <AlertTriangle className="w-4 h-4 text-amber-500" />
                    <h3 className="text-sm font-semibold text-slate-900">
                      High-Spending & Budget Warnings
                    </h3>
                  </div>
                  <span className="text-xs text-slate-500">
                    {analysis.overspending_categories?.length || 0} flagged categories
                  </span>
                </div>

                {!analysis.overspending_categories || analysis.overspending_categories.length === 0 ? (
                  <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center space-x-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>No critical overspending detected in this cycle. Good financial discipline!</span>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {analysis.overspending_categories.map((alert, idx) => (
                      <div
                        key={idx}
                        className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/80 space-y-1.5"
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-semibold text-slate-900 text-xs">{alert.category}</span>
                          <span
                            className={`text-[10px] font-medium px-2 py-0.5 rounded-full border ${
                              alert.severity === 'critical'
                                ? 'bg-rose-50 border-rose-200 text-rose-700'
                                : alert.severity === 'high'
                                ? 'bg-amber-50 border-amber-200 text-amber-700'
                                : 'bg-slate-100 border-slate-200 text-slate-700'
                            }`}
                          >
                            {alert.severity.toUpperCase()}
                          </span>
                        </div>
                        <p className="text-xs text-slate-600 leading-normal">
                          Spent {currency}{alert.spent.toLocaleString()} against budget of {currency}{alert.budget.toLocaleString()}
                        </p>
                        {alert.excess > 0 && (
                          <span className="text-xs text-rose-600 font-semibold block">
                            Excess: +{currency}{alert.excess.toLocaleString()}
                          </span>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Two Column Grid: Cost Cutting & Recommended Budgets */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Cost Cutting Opportunities */}
                <div className="bg-white border border-slate-200/80 rounded-xl p-5 space-y-4 shadow-xs">
                  <div className="flex items-center space-x-2 pb-3 border-b border-slate-100">
                    <TrendingDown className="w-4 h-4 text-emerald-600" />
                    <h3 className="text-sm font-semibold text-slate-900">Cost-Cutting & Savings Advice</h3>
                  </div>

                  <div className="space-y-3">
                    {analysis.cost_cutting_suggestions?.map((sugg, idx) => (
                      <div
                        key={idx}
                        className="p-3.5 rounded-xl bg-slate-50 border border-slate-100 flex items-start space-x-2.5"
                      >
                        <span className="w-5 h-5 rounded-full bg-slate-200 text-slate-700 text-xs font-semibold flex items-center justify-center shrink-0 mt-0.5">
                          {idx + 1}
                        </span>
                        <p className="text-xs text-slate-700 leading-normal">{sugg}</p>
                      </div>
                    ))}

                    {analysis.savings_suggestions?.slice(0, 2).map((sugg, idx) => (
                      <div
                        key={'sav-' + idx}
                        className="p-3.5 rounded-xl bg-slate-50 border border-slate-100 flex items-start space-x-2.5"
                      >
                        <span className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-800 text-xs font-semibold flex items-center justify-center shrink-0 mt-0.5">
                          ✓
                        </span>
                        <p className="text-xs text-slate-700 leading-normal">{sugg}</p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* AI Recommended Category Budgets */}
                <div className="bg-white border border-slate-200/80 rounded-xl p-5 space-y-4 shadow-xs">
                  <div className="flex items-center space-x-2 pb-3 border-b border-slate-100">
                    <Target className="w-4 h-4 text-slate-600" />
                    <h3 className="text-sm font-semibold text-slate-900">Recommended Category Limits</h3>
                  </div>

                  <div className="space-y-3">
                    {analysis.recommended_budget?.map((rec, idx) => (
                      <div
                        key={idx}
                        className="p-3.5 rounded-xl bg-slate-50 border border-slate-100 space-y-1"
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-semibold text-slate-900">{rec.category}</span>
                          <span className="text-xs font-medium text-emerald-700">
                            Suggested Cap: {currency}{rec.suggested_limit.toLocaleString()}
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 leading-normal">{rec.rationale}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Emergency Fund & Next Month Action Plan */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Emergency Fund Guide */}
                <div className="bg-white border border-slate-200/80 rounded-xl p-5 space-y-3 shadow-xs">
                  <div className="flex items-center space-x-2 pb-2 border-b border-slate-100">
                    <ShieldCheck className="w-4 h-4 text-slate-600" />
                    <h3 className="text-sm font-semibold text-slate-900">Emergency Fund Plan</h3>
                  </div>
                  <div className="space-y-2 text-xs">
                    <div className="flex justify-between py-1 border-b border-slate-100">
                      <span className="text-slate-500">Target Duration:</span>
                      <span className="font-medium text-slate-900">
                        {analysis.emergency_fund_suggestion?.target_months || 3} months
                      </span>
                    </div>
                    <div className="flex justify-between py-1 border-b border-slate-100">
                      <span className="text-slate-500">Recommended Target:</span>
                      <span className="font-bold text-slate-900">
                        {currency}
                        {(analysis.emergency_fund_suggestion?.recommended_target || 60000).toLocaleString()}
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 pt-1 leading-relaxed">
                      {analysis.emergency_fund_suggestion?.steps_to_reach ||
                        'Maintain at least 3 months of essential fixed costs to buffer against unexpected expenses.'}
                    </p>
                  </div>
                </div>

                {/* 4-Step Next Month Plan */}
                <div className="lg:col-span-2 bg-white border border-slate-200/80 rounded-xl p-5 space-y-3 shadow-xs">
                  <div className="flex items-center space-x-2 pb-2 border-b border-slate-100">
                    <Lightbulb className="w-4 h-4 text-amber-500" />
                    <h3 className="text-sm font-semibold text-slate-900">Next Month 4-Step Action Plan</h3>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                    {analysis.next_month_action_plan?.map((step, idx) => (
                      <div
                        key={idx}
                        className="p-3 rounded-xl bg-slate-50 border border-slate-100 flex items-start space-x-2.5"
                      >
                        <span className="w-5 h-5 rounded-full bg-slate-200 text-slate-700 text-xs font-semibold flex items-center justify-center shrink-0 mt-0.5">
                          {idx + 1}
                        </span>
                        <p className="text-xs text-slate-700 leading-normal">{step}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ) : null}
        </div>
      )}

      {/* Sub-Tab 2: Interactive AI Chatbot */}
      {activeSubTab === 'chat' && (
        <div className="bg-white border border-slate-200/80 rounded-xl flex flex-col h-[650px] overflow-hidden shadow-xs">
          {/* Chat Header */}
          <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/60">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-bold">
                <Bot className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-semibold text-slate-900 flex items-center gap-2">
                  Advisor Assistant
                  <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                </h3>
                <p className="text-xs text-slate-500">
                  Contextual advice based on your current transactions and budgets.
                </p>
              </div>
            </div>

            <button
              onClick={handleClearChat}
              className="p-1.5 rounded-md text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors text-xs flex items-center gap-1"
              title="Clear Chat History"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Clear Chat</span>
            </button>
          </div>

          {/* Messages Feed */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.length === 0 ? (
              <div className="py-12 text-center max-w-md mx-auto space-y-4">
                <div className="w-10 h-10 rounded-full bg-slate-100 text-slate-600 flex items-center justify-center mx-auto">
                  <Sparkles className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-slate-900">Ask Any Financial Question</h4>
                  <p className="text-xs text-slate-500 mt-1">
                    Your real financial records and budgets are referenced to provide personalized insights.
                  </p>
                </div>

                <div className="grid grid-cols-1 gap-2 pt-2">
                  {PROMPT_SUGGESTIONS.map((prompt, i) => (
                    <button
                      key={i}
                      onClick={() => handleSendMessage(prompt)}
                      className="text-left text-xs p-2.5 rounded-lg bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-700 transition-colors"
                    >
                      {prompt}
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              messages.map((m) => {
                const isUser = m.role === 'user';
                return (
                  <div
                    key={m.id}
                    className={`flex items-start space-x-2.5 ${isUser ? 'justify-end' : 'justify-start'}`}
                  >
                    {!isUser && (
                      <div className="w-7 h-7 rounded-lg bg-emerald-600 text-white flex items-center justify-center shrink-0 mt-0.5">
                        <Bot className="w-4 h-4" />
                      </div>
                    )}
                    <div
                      className={`max-w-[85%] sm:max-w-[75%] rounded-2xl px-4 py-3 text-xs leading-relaxed ${
                        isUser
                          ? 'bg-slate-900 text-white rounded-tr-xs'
                          : 'bg-slate-50 text-slate-800 border border-slate-200 rounded-tl-xs'
                      }`}
                    >
                      <div className="whitespace-pre-wrap">{m.content}</div>
                      <div
                        className={`text-[10px] mt-1.5 ${isUser ? 'text-slate-400' : 'text-slate-400'}`}
                      >
                        {new Date(m.timestamp).toLocaleTimeString([], {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </div>
                    </div>
                  </div>
                );
              })
            )}
            {loadingChat && (
              <div className="flex items-center space-x-2 text-slate-400 text-xs py-2">
                <div className="w-4 h-4 border-2 border-emerald-600/30 border-t-emerald-600 rounded-full animate-spin"></div>
                <span>Advisor is reviewing your financial records...</span>
              </div>
            )}
            <div ref={chatBottomRef} />
          </div>

          {/* Chat Input Bar */}
          <div className="p-3 border-t border-slate-100 bg-white">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSendMessage();
              }}
              className="flex items-center space-x-2"
            >
              <input
                type="text"
                placeholder="Ask about your budget, savings goals, or spending..."
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                disabled={loadingChat}
                className="flex-1 px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-slate-900 focus:bg-white transition-colors"
              />
              <button
                type="submit"
                disabled={!inputMessage.trim() || loadingChat}
                className="p-2.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white transition-colors disabled:opacity-40"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
