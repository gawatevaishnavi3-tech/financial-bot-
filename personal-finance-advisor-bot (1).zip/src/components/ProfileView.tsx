import React, { useState } from 'react';
import {
  User as UserIcon,
  RefreshCw,
  Check,
  Database,
} from 'lucide-react';
import { User } from '../types';
import { api } from '../api';

interface ProfileViewProps {
  user: User | null;
  onUpdateUser: (updated: User) => void;
  onResetDemoData: () => void;
  isResetting: boolean;
}

const SUPPORTED_CURRENCIES = [
  { symbol: '₹', name: 'Indian Rupee (INR)' },
  { symbol: '$', name: 'US Dollar (USD)' },
  { symbol: '€', name: 'Euro (EUR)' },
  { symbol: '£', name: 'British Pound (GBP)' },
];

export const ProfileView: React.FC<ProfileViewProps> = ({
  user,
  onUpdateUser,
  onResetDemoData,
  isResetting,
}) => {
  const [currency, setCurrency] = useState<string>(user?.currency || '₹');
  const [username, setUsername] = useState<string>(user?.username || '');
  const [saving, setSaving] = useState<boolean>(false);
  const [savedSuccess, setSavedSuccess] = useState<boolean>(false);

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setSaving(true);
      const res = await api.updateProfile({ currency, username });
      onUpdateUser(res.user);
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 3000);
    } catch (err: any) {
      alert(err.message || 'Failed to update preferences.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Top Banner */}
      <div className="pb-2">
        <h1 className="text-2xl font-bold tracking-tight text-slate-900 flex items-center gap-2">
          Profile & Settings
        </h1>
        <p className="text-sm text-slate-500 mt-0.5">
          Manage currency settings, account details, and demonstration data.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* User Card */}
        <div className="bg-white border border-slate-200/80 rounded-xl p-6 text-center space-y-4 shadow-xs">
          <div className="w-16 h-16 rounded-full bg-slate-900 text-white font-bold text-xl flex items-center justify-center mx-auto">
            {user?.username?.charAt(0).toUpperCase() || 'U'}
          </div>

          <div>
            <h2 className="text-base font-semibold text-slate-900">{user?.username}</h2>
            <p className="text-xs text-slate-500">{user?.email}</p>
          </div>

          <div className="pt-2 border-t border-slate-100 flex justify-center space-x-2 text-xs">
            <span className="px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 font-medium">
              Active Account
            </span>
            <span className="px-2.5 py-1 rounded-full bg-slate-100 text-slate-700 font-medium">
              Currency: {user?.currency}
            </span>
          </div>
        </div>

        {/* Profile Settings Form */}
        <div className="md:col-span-2 bg-white border border-slate-200/80 rounded-xl p-6 space-y-5 shadow-xs">
          <h3 className="text-sm font-semibold text-slate-900 pb-3 border-b border-slate-100">
            Account Preferences
          </h3>

          {savedSuccess && (
            <div className="p-3 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2">
              <Check className="w-4 h-4 text-emerald-600" />
              <span>Preferences successfully saved!</span>
            </div>
          )}

          <form onSubmit={handleSaveProfile} className="space-y-4 text-xs">
            <div>
              <label className="block font-medium text-slate-700 mb-1">Display Name</label>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-slate-200 rounded-lg text-slate-900 focus:outline-none focus:border-slate-900"
                required
              />
            </div>

            <div>
              <label className="block font-medium text-slate-700 mb-1">Email Address</label>
              <input
                type="email"
                value={user?.email || ''}
                disabled
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-500 cursor-not-allowed"
              />
            </div>

            <div>
              <label className="block font-medium text-slate-700 mb-1">Preferred Currency</label>
              <div className="grid grid-cols-2 gap-2">
                {SUPPORTED_CURRENCIES.map((curr) => (
                  <button
                    key={curr.symbol}
                    type="button"
                    onClick={() => setCurrency(curr.symbol)}
                    className={`p-2.5 rounded-lg border text-left transition-colors ${
                      currency === curr.symbol
                        ? 'bg-slate-900 text-white border-slate-900'
                        : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <span className="font-bold text-sm mr-2">{curr.symbol}</span>
                    <span className="text-xs">{curr.name}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="submit"
                disabled={saving}
                className="px-4 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-medium text-xs transition-colors disabled:opacity-50"
              >
                {saving ? 'Saving...' : 'Save Changes'}
              </button>
            </div>
          </form>
        </div>
      </div>

      {/* Demo State Reset Box */}
      <div className="bg-white border border-slate-200/80 rounded-xl p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-xs">
        <div className="space-y-1">
          <div className="flex items-center space-x-2">
            <Database className="w-4 h-4 text-slate-600" />
            <h3 className="text-sm font-semibold text-slate-900">Reset Demo Database</h3>
          </div>
          <p className="text-xs text-slate-500 max-w-xl leading-relaxed">
            Re-populates the database with realistic sample income entries, categorized daily expenses, monthly budget limits, and savings goals.
          </p>
        </div>

        <button
          onClick={onResetDemoData}
          disabled={isResetting}
          className="flex items-center space-x-2 px-3.5 py-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-medium transition-colors shrink-0 disabled:opacity-50"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isResetting ? 'animate-spin' : ''}`} />
          <span>{isResetting ? 'Resetting...' : 'Reset to Sample Data'}</span>
        </button>
      </div>
    </div>
  );
};
