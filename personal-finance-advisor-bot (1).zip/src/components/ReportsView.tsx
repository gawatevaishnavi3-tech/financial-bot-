import React, { useState, useEffect } from 'react';
import {
  FileText,
  Printer,
  Sparkles,
  Calendar,
} from 'lucide-react';
import { FinancialReport } from '../types';
import { api } from '../api';

interface ReportsViewProps {
  currency: string;
}

export const ReportsView: React.FC<ReportsViewProps> = ({ currency }) => {
  const now = new Date();
  const [selectedMonth, setSelectedMonth] = useState<number>(now.getMonth() + 1);
  const [selectedYear, setSelectedYear] = useState<number>(now.getFullYear());

  const [activeReport, setActiveReport] = useState<FinancialReport | null>(null);
  const [reportHistory, setReportHistory] = useState<FinancialReport[]>([]);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [loadingHistory, setLoadingHistory] = useState<boolean>(true);

  const fetchHistory = async () => {
    try {
      setLoadingHistory(true);
      const res = await api.getReports();
      setReportHistory(res.reports);
      if (res.reports.length > 0 && !activeReport) {
        setActiveReport(res.reports[0]);
      }
    } catch (err: any) {
      console.error('Failed to fetch reports:', err);
    } finally {
      setLoadingHistory(false);
    }
  };

  useEffect(() => {
    fetchHistory();
  }, []);

  const handleGenerateReport = async () => {
    try {
      setIsGenerating(true);
      const res = await api.generateReport(selectedMonth, selectedYear);
      setActiveReport(res.report);
      fetchHistory();
    } catch (err: any) {
      alert(err.message || 'Failed to generate monthly summary report.');
    } finally {
      setIsGenerating(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const MONTH_NAMES = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  return (
    <div className="space-y-6">
      {/* Top Banner (Hidden during Print) */}
      <div className="print:hidden flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-2">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 flex items-center gap-2">
            Reports & Statements
          </h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Generate monthly financial statements and printable PDF audits.
          </p>
        </div>

        {activeReport && (
          <button
            onClick={handlePrint}
            className="flex items-center space-x-1.5 px-3.5 py-2 rounded-lg text-xs font-medium bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 shadow-xs transition-colors self-start sm:self-auto"
          >
            <Printer className="w-3.5 h-3.5 text-slate-500" />
            <span>Print / Save PDF</span>
          </button>
        )}
      </div>

      {/* Report Generator Controls (Hidden during Print) */}
      <div className="print:hidden bg-white border border-slate-200/80 rounded-xl p-4 shadow-xs flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
          <div className="flex items-center space-x-2 text-slate-600">
            <Calendar className="w-4 h-4 text-slate-500" />
            <span className="text-xs font-medium text-slate-700">Period:</span>
          </div>

          <select
            value={selectedMonth}
            onChange={(e) => setSelectedMonth(parseInt(e.target.value))}
            className="px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs text-slate-900 focus:outline-none focus:border-slate-900"
          >
            {MONTH_NAMES.map((name, i) => (
              <option key={i + 1} value={i + 1}>
                {name}
              </option>
            ))}
          </select>

          <select
            value={selectedYear}
            onChange={(e) => setSelectedYear(parseInt(e.target.value))}
            className="px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs text-slate-900 focus:outline-none focus:border-slate-900"
          >
            {[2024, 2025, 2026, 2027].map((yr) => (
              <option key={yr} value={yr}>
                {yr}
              </option>
            ))}
          </select>
        </div>

        <button
          onClick={handleGenerateReport}
          disabled={isGenerating}
          className="w-full md:w-auto flex items-center justify-center space-x-2 px-4 py-2 rounded-lg text-xs font-medium bg-slate-900 hover:bg-slate-800 text-white transition-colors disabled:opacity-50"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>{isGenerating ? 'Compiling Statement...' : 'Generate Statement'}</span>
        </button>
      </div>

      {/* Main Printable Document Area */}
      {activeReport ? (
        <div className="bg-white border border-slate-200/90 rounded-xl p-8 shadow-xs space-y-6 print:border-none print:shadow-none print:p-0">
          {/* Statement Header */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-6 border-b border-slate-100 gap-4">
            <div>
              <span className="text-[11px] font-semibold uppercase tracking-wider text-emerald-700 block">
                Monthly Financial Statement
              </span>
              <h2 className="text-2xl font-bold text-slate-900 mt-1">
                {MONTH_NAMES[activeReport.month - 1]} {activeReport.year} Summary
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Statement ID: <span className="font-mono">{activeReport.id}</span> • Generated on{' '}
                {new Date(activeReport.created_at).toLocaleDateString()}
              </p>
            </div>

            <div className="text-left sm:text-right">
              <span className="text-xs font-medium text-slate-800 block">
                Personal Finance Advisor
              </span>
              <span className="text-xs text-slate-500">
                Verified Ledger Statement
              </span>
            </div>
          </div>

          {/* 4 Financial Core Metric Tiles */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
              <span className="text-xs text-slate-500 font-medium block">
                Total Income
              </span>
              <div className="text-xl font-bold text-slate-900 mt-1">
                {currency}{activeReport.income.toLocaleString()}
              </div>
            </div>

            <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
              <span className="text-xs text-slate-500 font-medium block">
                Total Expenses
              </span>
              <div className="text-xl font-bold text-slate-900 mt-1">
                {currency}{activeReport.expenses.toLocaleString()}
              </div>
            </div>

            <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
              <span className="text-xs text-slate-500 font-medium block">
                Net Savings
              </span>
              <div
                className={`text-xl font-bold mt-1 ${
                  activeReport.savings >= 0 ? 'text-slate-900' : 'text-rose-600'
                }`}
              >
                {currency}{activeReport.savings.toLocaleString()}
              </div>
            </div>

            <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
              <span className="text-xs text-slate-500 font-medium block">
                Highest Category
              </span>
              <div className="text-sm font-bold text-slate-900 mt-1 truncate">
                {activeReport.highest_category || 'N/A'}
              </div>
              <span className="text-xs text-slate-500">
                {currency}{activeReport.highest_category_amount.toLocaleString()}
              </span>
            </div>
          </div>

          {/* AI Advisor Remarks */}
          <div className="bg-emerald-50/50 p-5 rounded-xl border border-emerald-200/70 space-y-2">
            <div className="flex items-center space-x-2">
              <Sparkles className="w-4 h-4 text-emerald-700" />
              <h3 className="text-sm font-semibold text-slate-900">
                Advisor Notes & Summary
              </h3>
            </div>
            <p className="text-xs text-slate-700 leading-relaxed whitespace-pre-wrap">
              {activeReport.ai_summary ||
                'Audit completed. Income and expenses tracked within acceptable tolerances.'}
            </p>
          </div>

          {/* Signoff / Disclaimer */}
          <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row justify-between text-[11px] text-slate-400">
            <span>Verified by Personal Finance Advisor Ledger.</span>
            <span>Confidential Financial Document.</span>
          </div>
        </div>
      ) : (
        <div className="bg-white border border-slate-200/80 rounded-xl p-12 text-center text-slate-400 shadow-xs">
          <FileText className="w-10 h-10 text-slate-300 mx-auto mb-3" />
          <p className="text-sm font-medium text-slate-700">No Monthly Statement Generated Yet</p>
          <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1">
            Pick a month above and click "Generate Statement" to compile an official summary.
          </p>
        </div>
      )}

      {/* History Archive list (Hidden during print) */}
      {reportHistory.length > 1 && (
        <div className="print:hidden bg-white border border-slate-200/80 rounded-xl p-5 shadow-xs space-y-3">
          <h3 className="text-sm font-semibold text-slate-900">Past Statements</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
            {reportHistory.map((rep) => (
              <button
                key={rep.id}
                onClick={() => setActiveReport(rep)}
                className={`text-left p-3 rounded-lg border text-xs transition-colors ${
                  activeReport?.id === rep.id
                    ? 'bg-slate-900 text-white border-slate-900'
                    : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                }`}
              >
                <div className="font-semibold">
                  {MONTH_NAMES[rep.month - 1]} {rep.year}
                </div>
                <div className={`text-xs mt-0.5 ${activeReport?.id === rep.id ? 'text-slate-300' : 'text-slate-500'}`}>
                  Savings: {currency}{rep.savings.toLocaleString()}
                </div>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
